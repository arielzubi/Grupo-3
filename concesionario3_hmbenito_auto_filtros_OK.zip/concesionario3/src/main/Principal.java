package main;

import view.Panta_auto;
import view.Panta_consulta;
import view.Panta_marca;
import view.Panta_modelo;
import view.Panta_version;
import view.Panta_principal;
import controlador.AutoControlador;
import model.Auto;
import model.AutoDao;

import controlador.PantallaControlador;
import model.Marca;
import model.MarcaDao;
import model.Modelo;
import model.ModeloDao;
import model.Version;
import model.VersionDao;


public class Principal {

/**
 *
 * @author hmb
 */
  Auto auto = new Auto();
        AutoDao autoDao = new AutoDao();
        Marca marca = new Marca();
        MarcaDao marcaDao = new MarcaDao();
        Modelo modelo = new Modelo();
        ModeloDao modeloDao = new ModeloDao();
        Version version = new Version();
        VersionDao versionDao = new VersionDao();
        Panta_auto pantaauto = new Panta_auto();
        Panta_consulta pantaconsulta = new Panta_consulta();
        Panta_marca pantamarca = new Panta_marca();
        Panta_modelo pantamodelo = new Panta_modelo();
        Panta_version pantaversion = new Panta_version();
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("pase por main linea 21");
        Panta_principal panta = new Panta_principal();
        panta.setVisible(true);
         
        
         System.out.println("en Panta_principal inicializa AutoControlador linea 46");
        System.out.println("sali de main linea 25");
       
        } 
}