package model;

/**
 *
 * @author cfp40
 */
public class Marca {
    
    private int idmarca;
    private String nombre_marca;

    public Marca() {
    }

    public Marca(String nombre_marca) {
        this.nombre_marca = nombre_marca;
    }
    
    public Marca(int idmarca, String nombre_marca) {
        this.idmarca = idmarca;
        this.nombre_marca = nombre_marca;
    }

    public int getIdmarca() {
        return idmarca;
    }

    public void setIdmarca(int idmarca) {
        this.idmarca = idmarca;
    }

    public String getNombre_marca() {
        return nombre_marca;
    }

    public void setNombre_marca(String nombre_marca) {
        this.nombre_marca = nombre_marca;
    }

}
