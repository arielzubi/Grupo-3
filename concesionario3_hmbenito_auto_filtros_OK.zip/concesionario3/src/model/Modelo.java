
package model;

public class Modelo {
    private int idmodelo;
    private String nombre_marca;
    private String nombre_modelo;
    private int idmarca;

    public Modelo() {
    }

    public int getIdmodelo() {
        return idmodelo;
    }

    public Modelo(int idmodelo, String nombre_modelo, int idmarca, String nombre_marca) {
        this.idmodelo = idmodelo;
        this.nombre_modelo = nombre_modelo;
        this.idmarca = idmarca;
        this.nombre_marca = nombre_marca;
    }

      
    public void setIdmodelo(int idmodelo) {
        this.idmodelo = idmodelo;
    }

    public String getNombre_modelo() {
        return nombre_modelo;
    }

    public void setNombre_modelo(String nombre_modelo) {
        this.nombre_modelo = nombre_modelo;
    }

    public int getIdmarca() {
        return idmarca;
    }

    public void setIdmarca(int idmarca) {
        this.idmarca = idmarca;
    }

    public String getNombre_marca() {
        return nombre_marca;
    }

    public void setNombre_marca(String nombre_marca) {
        this.nombre_marca = nombre_marca;
    }
    
}
