package controlador;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseAdapter;
import java.awt.color.*;
import view.Panta_principal;
import view.Panta_auto;
import view.Panta_marca;
import view.Panta_modelo;
import view.Panta_version;
// importaciones necesarias para trabajar con audios y sonidos
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;
import java.io.File;



/**
 *
 * @author hmb
 */
   
public class PantallaControlador implements ActionListener,KeyListener, MouseListener,MouseMotionListener {
    
    private Panta_principal panta;
    private Panta_auto pantaauto;
    private Panta_marca pantamarca;
    private Panta_modelo pantamodelo;
    private Panta_version pantaversion;
    private int selector;

    
     public PantallaControlador(Panta_principal panta, Panta_auto pantaauto, Panta_marca pantamarca, Panta_modelo pantamodelo, Panta_version pantaversion) {
        this.panta = panta;
        this.pantaauto = pantaauto;
        this.pantamarca = pantamarca;
        this.pantamodelo = pantamodelo;
        this.pantaversion = pantaversion;
        
           this.panta.btn_auto.addActionListener(this);
            this.panta.btn_marca.addActionListener(this);
            this.panta.btn_modelo.addActionListener(this);
            this.panta.btn_version.addActionListener(this);
            this.pantaauto.btn_volver.addActionListener(this);
            this.pantamarca.btn_volver_marca.addActionListener(this);
            this.pantamodelo.btn_volver_modelo.addActionListener(this);
            this.pantaversion.btn_volver_version.addActionListener(this);
            this.panta.btn_auto.addMouseMotionListener(this);
            this.panta.btn_marca.addMouseMotionListener(this);
            this.panta.btn_modelo.addMouseMotionListener(this);
            this.panta.btn_version.addMouseMotionListener(this);
            this.pantaauto.btn_volver.addMouseMotionListener(this);
            this.pantamarca.btn_volver_marca.addMouseMotionListener(this);
            this.pantamodelo.btn_volver_modelo.addMouseMotionListener(this);
            this.pantaversion.btn_volver_version.addMouseMotionListener(this);
            this.panta.btn_auto.addMouseListener(this);
            this.panta.btn_marca.addMouseListener(this);
            this.panta.btn_modelo.addMouseListener(this);
            this.panta.btn_version.addMouseListener(this);
            this.pantaauto.btn_volver.addMouseListener(this);
            this.pantamarca.btn_volver_marca.addMouseListener(this);
            this.pantamodelo.btn_volver_modelo.addMouseListener(this);
            this.pantaversion.btn_volver_version.addMouseListener(this);                   
            this.panta.lbl_imagenpantalla.addMouseListener(this);
System.out.println ("pase por autocontroller linea 48 addListener");

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == panta.btn_auto){selector = 1;}
        if(e.getSource() == panta.btn_marca){selector = 2;}
        if(e.getSource() == panta.btn_modelo){selector = 3;}
        if(e.getSource() == panta.btn_version){selector = 4;
        System.out.println ("pase por autocontroller linea 67 abrirPantallaVersion - SELECTOR "+selector);
        }
        if(e.getSource() == pantaauto.btn_volver){selector = 5;}
        if(e.getSource() == pantamarca.btn_volver_marca){selector = 6;}
        if(e.getSource() == pantamodelo.btn_volver_modelo){selector = 7;}
        if(e.getSource() == pantaversion.btn_volver_version){selector = 8;}

        switch(selector){
            case 1: abrirPantallaAuto();
            break;
            case 2: abrirPantallaMarca();
            break;
            case 3: abrirPantallaModelo();
            break;
            case 4: abrirPantallaVersion();
            break;
            case 5: volverPantallaPrincipal();
            break;
            case 6: volverPantallaPrincipal();
            break;
            case 7: volverPantallaPrincipal();
            break;
            case 8: volverPantallaPrincipal();
            break;
         }
    }

    @Override
    public void keyTyped(KeyEvent e) {}
        
    @Override
    public void keyPressed(KeyEvent e) {}
    
    @Override
    public void keyReleased(KeyEvent e) {}
        
    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource() == panta.btn_auto){selector = 1;}
        if(e.getSource() == panta.btn_marca){selector = 2;}
        if(e.getSource() == panta.btn_modelo){selector = 3;}
        if(e.getSource() == panta.btn_version){selector = 4;
        System.out.println ("pase por autocontroller linea 119 abrirPantallaVersion - SELECTOR "+selector);
        }
        if(e.getSource() == pantaauto.btn_volver){selector = 5;}
        if(e.getSource() == pantamarca.btn_volver_marca){selector = 6;}
        if(e.getSource() == pantamodelo.btn_volver_modelo){selector = 7;}
        if(e.getSource() == pantaversion.btn_volver_version){selector = 8;
        System.out.println ("pase por autocontroller linea 125 volverPantallaPrincipal - SELECTOR "+selector);
        }

        switch(selector){
            case 1: abrirPantallaAuto();
            break;
            case 2: abrirPantallaMarca();
            break;
            case 3: abrirPantallaModelo();
            break;
            case 4: abrirPantallaVersion();
            System.out.println ("pase por autocontroller linea 132 abrirPantallaVersion - CASE4");
            break;
            case 5: volverPantallaPrincipal();
            break;
            case 6: volverPantallaPrincipal();
            break;
            case 7: volverPantallaPrincipal();
            break;
            case 8: volverPantallaPrincipal();
            System.out.println ("pase por autocontroller linea 141 volverPantallaPrincipal - CASE8");
            break;
            default :
            System.out.println ("pase por autocontroller linea 148 Default Switch");
            }
    }
        
    @Override
    public void mousePressed(MouseEvent e) {}
        
    @Override
    public void mouseReleased(MouseEvent e) {}
    
    @Override
    public void mouseEntered(MouseEvent e) {
     if(e.getSource() == panta.btn_auto){selector = 1;}
        if(e.getSource() == panta.btn_marca){selector = 2;}
        if(e.getSource() == panta.btn_modelo){selector = 3;}
        if(e.getSource() == panta.btn_version){selector = 4;
        System.out.println ("pase por autocontroller linea 119 abrirPantallaVersion - SELECTOR "+selector);
           }
        if(e.getSource() == pantaauto.btn_volver){selector = 5;}
        if(e.getSource() == pantamarca.btn_volver_marca){selector = 6;}
        if(e.getSource() == pantamodelo.btn_volver_modelo){selector = 7;}
        if(e.getSource() == pantaversion.btn_volver_version){selector = 8;}
        if(e.getSource() == panta.lbl_imagenpantalla){selector = 9;
        System.out.println ("pase por autocontroller linea 171 volverPantallaPrincipal - SELECTOR "+selector);
        }

        switch(selector){
            case 1: panta.btn_auto.setBackground(Color.green); // Color al pasar el mouse;
            break;
            case 2: panta.btn_marca.setBackground(Color.green);
            break;
            case 3: panta.btn_modelo.setBackground(Color.green);
            break;
            case 4: panta.btn_version.setBackground(Color.green);
            System.out.println ("pase por autocontroller linea 174 abrirPantallaVersion - CASE4");
            break;
            case 5: pantaauto.btn_volver.setBackground(Color.green);
            break;
            case 6: pantamarca.btn_volver_marca.setBackground(Color.green);
            break;
            case 7: pantamodelo.btn_volver_modelo.setBackground(Color.green);
            break;
            case 8: pantaversion.btn_volver_version.setBackground(Color.green);
            System.out.println ("pase por autocontroller linea 183 volverPantallaPrincipal - CASE8");
            break;
            case 9:  panta.lbl_imagenpantalla.setBackground(Color.green);
                try {
                       AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(getClass().getResource("/audio/car_engine_start.wav"));
                       Clip clip = AudioSystem.getClip();
                       clip.open(audioInputStream);
                       clip.start();}
                catch (Exception ex) {
                        ex.printStackTrace();
                }   System.out.println ("pase por autocontroller linea 201 volverPantallaPrincipal - CASE8");
            
            break;
            default :
            System.out.println ("pase por autocontroller linea 205 Default Switch");
        }
    }

    @Override
    public void mouseExited(MouseEvent e) {
     if(e.getSource() == panta.btn_auto){selector = 1;}
        if(e.getSource() == panta.btn_marca){selector = 2;}
        if(e.getSource() == panta.btn_modelo){selector = 3;}
        if(e.getSource() == panta.btn_version){selector = 4;
        System.out.println ("pase por autocontroller linea 215 abrirPantallaVersion - SELECTOR "+selector);
        }
        if(e.getSource() == pantaauto.btn_volver){selector = 5;}
        if(e.getSource() == pantamarca.btn_volver_marca){selector = 6;}
        if(e.getSource() == pantamodelo.btn_volver_modelo){selector = 7;}
        if(e.getSource() == pantaversion.btn_volver_version){selector = 8;
        System.out.println ("pase por autocontroller linea 221 volverPantallaPrincipal - SELECTOR "+selector);
        }

        switch(selector){
            case 1: panta.btn_auto.setBackground(Color.LIGHT_GRAY);// Color al pasar el mouse;
            break;
            case 2: panta.btn_marca.setBackground(Color.LIGHT_GRAY);
            break;
            case 3: panta.btn_modelo.setBackground(Color.LIGHT_GRAY);
            break;
            case 4: panta.btn_version.setBackground(Color.LIGHT_GRAY);
            System.out.println ("pase por autocontroller linea 232 abrirPantallaVersion - CASE4");
            break;
            case 5: pantaauto.btn_volver.setBackground(Color.LIGHT_GRAY);
            break;
            case 6: pantamarca.btn_volver_marca.setBackground(Color.LIGHT_GRAY);
            break;
            case 7: pantamodelo.btn_volver_modelo.setBackground(Color.LIGHT_GRAY);
            break;
            case 8: pantaversion.btn_volver_version.setBackground(Color.LIGHT_GRAY);
            System.out.println ("pase por autocontroller linea 241 volverPantallaPrincipal - CASE8");
            break;
            default :
            System.out.println ("pase por autocontroller linea 244 Default Switch");
            }
    }
    
    @Override
    public void mouseDragged(MouseEvent e) {}

    @Override
    public void mouseMoved(MouseEvent e) {}
    
    
    public Panta_principal getPanta() {
        return panta;
    }

    public void setPanta(Panta_principal panta) {
        this.panta = panta;
    }

    public Panta_auto getPantaauto() {
        return pantaauto;
    }

    public void setPantaauto(Panta_auto pantaauto) {
        this.pantaauto = pantaauto;
    }

    public Panta_marca getPantamarca() {
        return pantamarca;
    }

    public void setPantamarca(Panta_marca pantamarca) {
        this.pantamarca = pantamarca;
    }

    public Panta_modelo getPantamodelo() {
        return pantamodelo;
    }

    public void setPantamodelo(Panta_modelo pantamodelo) {
        this.pantamodelo = pantamodelo;
    }

    public Panta_version getPantaversion() {
        return pantaversion;
    }

    public void setPantaversion(Panta_version pantaversion) {
        this.pantaversion = pantaversion;
    }

    public int getSelector() {
        return selector;
    }

    public void setSelector(int selector) {
        this.selector = selector;
    }

    // Abrir pantalla Auto
        public void abrirPantallaAuto() {

        PantallaControlador auto = new PantallaControlador(panta, pantaauto, pantamarca,
                pantamodelo, pantaversion);
        // Colocar PantallaMarca en la misma posición que Pantallas
        pantaauto.setLocation(panta.getLocation());
        
        // Hacer visible PantallaMarca
        pantaauto.setVisible(true);
        
        // Cerrar Pantallas
        panta.setVisible(false);
        panta.dispose();
        
        System.out.println ("pase por autocontroller linea 224 abrirPantallaAuto");
    }
    
    
    // Abrir pantalla Marca
    public void abrirPantallaMarca() {
    
        PantallaControlador auto = new PantallaControlador(panta, pantaauto, pantamarca,
                pantamodelo, pantaversion);
        // Colocar PantallaMarca en la misma posición que Pantallas
        pantamarca.setLocation(panta.getLocation());
        
        // Hacer visible PantallaMarca
        pantamarca.setVisible(true);
                        
        // Cerrar Pantallas
        panta.setVisible(false);
        panta.dispose();
        
        System.out.println ("pase por autocontroller linea 244 abrirPantallaMArca");
    }
    
    // Abrir pantalla Modelo
    public void abrirPantallaModelo() {
    
        PantallaControlador auto = new PantallaControlador(panta, pantaauto, pantamarca,
                pantamodelo, pantaversion);
        // Colocar PantallaModelo en la misma posición que Pantallas
        pantamodelo.setLocation(panta.getLocation());
        
        // Hacer visible PantallaMarca
        pantamodelo.setVisible(true);
                        
        // Cerrar Pantallas
        panta.setVisible(false);
        panta.dispose();
        
        System.out.println ("pase por autocontroller linea 263 abrirPantallaModelo");
    }
    
    // Abrir pantalla Version
    public void abrirPantallaVersion() {
    
        PantallaControlador auto = new PantallaControlador(panta, pantaauto, pantamarca,
                pantamodelo, pantaversion);
        
        // Colocar PantallaModelo en la misma posición que Pantallas
        pantaversion.setLocation(panta.getLocation());
        
        // Hacer visible PantallaMarca
        pantaversion.setVisible(true);
                        
        // Cerrar Pantallas
        panta.setVisible(false);
        panta.dispose();
        
        System.out.println ("pase por autocontroller linea 282 abrirPantallaVersion");
    }

   
       // Reabrir la pantalla principal
     public void volverPantallaPrincipal() {
     
        System.out.println ("pase por autocontroller linea 118 volverPantallaPricipal");
        panta.setLocationRelativeTo(null);
        panta.setVisible(true);
        
        // Cerrar PantallaMarca
         pantamarca.dispose();
         pantaauto.dispose();
         pantamodelo.dispose();
         pantaversion.dispose();
    }
    
}