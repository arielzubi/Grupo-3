package model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;


public class ModeloDao {
    
    Conexion cn = new Conexion();
    Connection con;
      
    PreparedStatement pst;
    ResultSet rs;

    JComboBox cmb_modelo_version = new JComboBox<>();
    JComboBox cmb_modelo = new JComboBox<>();
    
    public boolean agregarNombre_modelo(Modelo modelo) {
    // a copmtinuacion en el comando a enviar a MySQL, se escriben los campos de la misma forma que se declararon en las tablas
    System.out.println("en ModeloDao query AGREGAR linea 25");
    String query = "INSERT INTO modelo (nombre_modelo, idmarca) VALUES(?,?)";
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         //a continuacion los modelo.getXXXXXX se escriben de la misma forma que se declararon en la clase Nombre_modelo
         pst.setString( 1,modelo.getNombre_modelo());
         pst.setInt( 2,modelo.getIdmarca());
         pst.execute();
                return true;
         } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, "Error al registrar el modelo" + e);
                return false;
         }
}
public boolean modificarNombre_modelo(Modelo modelo) {
    System.out.println("en ModeloDao query MODIFICAR linea 41"); 
    String query = "UPDATE modelo  SET nombre_modelo = ?"
                        + "WHERE idmodelo = ? ";
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         //hacemos validaciones para asegurar que los campos no esten vacíos
              // Validar campos vacíos
        
         //a continuacion los modelo.getXXXXXX se escriben de la misma forma que se declararon en la clase Nombre_modelo
         pst.setString(1, modelo.getNombre_modelo());
         pst.setInt(2, modelo.getIdmarca());
         pst.execute();
                return true;
         } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, "Error al actualizar el modelo" + e);
                return false;
         }  
}
public boolean borrarNombre_modelo(int idmodelo) {
    System.out.println("en ModeloDao query BORRAR linea 61");
    String query = "DELETE FROM modelo WHERE idmodelo = " + idmodelo;
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         // no necesito las definiciones de los metodos anteriores, porque solo necesito el id para borrar el registro
         pst.execute();
                return true;
         } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, "Error al borrar el modelo" + e);
                return false;
         }              
}

public List listarNombre_modelo() {
    System.out.println("en ModeloDao query LISTAR linea 76");
    List<Modelo> list_modelo = new ArrayList();
    String query = "SELECT ma.nombre_marca, mo.nombre_modelo, mo.idmodelo FROM modelo AS mo" +
       " INNER JOIN marca AS ma ON mo.idmarca = ma.idmarca"  +
            " order by mo.nombre_modelo asc;";
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         rs = pst.executeQuery();
         //a continuacion los modelo.getXXXXXX se escriben de la misma forma que se declararon en la clase Nombre_modelo
         while(rs.next()) {
            Modelo modelo = new Modelo();
          
            modelo.setNombre_marca(rs.getString("nombre_marca"));
            modelo.setNombre_modelo(rs.getString("nombre_modelo"));
            modelo.setIdmodelo(rs.getInt("idmodelo"));
            cmb_modelo_version.addItem(rs.getString("nombre_modelo"));
            cmb_modelo.addItem(rs.getString("nombre_modelo"));

         list_modelo.add(modelo);
         }
                 } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, e.toString());
                         }
                return list_modelo;
         }
//Buscar id de modelo
    public int buscarIdmodelo(String nombre_modelo){
        int id = 0;
        String query = "SELECT idmodelo FROM modelo WHERE nombre_modelo = '" + nombre_modelo + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idmodelo");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de modelo" + e);
        }
        return id;
    }
    
}
