package model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;



public class MarcaDao {
    
    Conexion cn = new Conexion();
    Connection con;
      
    PreparedStatement pst;
    ResultSet rs;
    JComboBox cmb_marca_modelo = new JComboBox<>();
    JComboBox cmb_marca_version = new JComboBox<>();
    JComboBox cmb_marca = new JComboBox<>();
    
    public boolean agregarNombre_marca(Marca marca) {
             System.out.println("pase por MarcaDao linea 25 agregarNombreMarca" + marca);
        // a copmtinuacion en el comando a enviar a MySQL, se escriben los campos de la misma forma que se declararon en las tablas
 String query = "INSERT INTO marca (nombre_marca) VALUES(?)";
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         //a continuacion los marca.getXXXXXX se escriben de la misma forma que se declararon en la clase Nombre_marca
         pst.setString( 1,marca.getNombre_marca());
         pst.execute();
                return true;
         } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, "Error al registrar la marca" + e);
                return false;
         }
}
public boolean modificarNombre_marca(Marca marca) {
 String query = "UPDATE marca  SET nombre_marca = ?"
                        + "WHERE idmarca = ? ";
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);

         pst.setString(1,marca.getNombre_marca());
         pst.setInt(2,marca.getIdmarca());
         pst.execute();
                return true;
         } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, "Error al actualizar el marca" + e);
                return false;
         }  
}
public boolean borrarNombre_marca(int idmarca) {
 String query = "DELETE FROM marca WHERE idmarca = " + idmarca;
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         pst.execute();
                return true;
         } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, "Error al borrar el marca" + e);
                return false;
         }              
}

public List listarNombre_marca() {
    System.out.println ("pase por marcaDao linea 69 query SELECT listarNombre_marca");
    List<Marca> list_marca = new ArrayList();
    String query = "SELECT * FROM marca";
           
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         rs = pst.executeQuery();

         
         while(rs.next()) {
              Marca marca = new Marca();
            marca.setIdmarca(rs.getInt("idmarca"));  
            marca.setNombre_marca(rs.getString("nombre_marca"));
            cmb_marca_modelo.addItem(rs.getString("nombre_marca"));
            cmb_marca_version.addItem(rs.getString("nombre_marca"));
            cmb_marca.addItem(rs.getString("nombre_marca"));
         list_marca.add(marca);
         }
                 } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, e.toString());
                         }
          System.out.println("pase por MarcaDao linea 92 despues de listarNombreMarcas");  
                return list_marca;
         }     
 //Buscar id de marca
    public int buscarIdmarca(String nombre_marca){
        System.out.println ("pase por marcaDao linea 96 query SELECT buscarIdmarca");
        int id = 0;
        String query = "SELECT idmarca FROM marca WHERE nombre_marca = '" + nombre_marca + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idmarca");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de marca" + e);
        }
         System.out.println ("pase por marcaDao linea 110 Metodo BUSCARidMarca id = " + id + nombre_marca);
        return id;
    }

}
