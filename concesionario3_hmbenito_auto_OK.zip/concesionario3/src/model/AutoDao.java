package model;

/**
 *
 * @author hmb
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;


public class AutoDao {
    
       //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;


    public AutoDao() {
        System.out.println("pase por AutoDao linea 29");
    }
    
    
    //Agregar auto
    public boolean agregarAuto(Auto auto){
        System.out.println("en AutoDao query AGREGAR linea 35");
        
        String query = "INSERT INTO auto (idmarca, idmodelo, idversion, anio,"
                + " precio, kilometros, combustible, puertas, condicion) VALUES(?,?,?,?,?,?,?,?,?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            
            pst.setInt(1,auto.getIdmarca());
            pst.setInt(2,auto.getIdmodelo());
            pst.setInt(3,auto.getIdversion());
            pst.setInt(4,auto.getAnio());
            pst.setFloat(5,auto.getPrecio());
            pst.setInt(6,auto.getKilometros());
            pst.setString(7,auto.getCombustible());
            pst.setInt(8,auto.getPuertas());
            pst.setString(9,auto.getCondicion());
            pst.execute();
            
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar el auto" + e);
            return false;
        }
    }
    
    //Modificar auto
    public boolean modificarAuto(Auto auto){
        
        System.out.println("en AutoDao query MODIFICAR linea 64");
        
        String query = "UPDATE auto SET idmarca = ?, idmodelo = ?, idversion = ?, anio = ?,"
                + " precio = ?, kilometros = ?, combustible = ?, puertas = ?, condicion = ? WHERE idauto = ? ";
                
                
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
       
            pst.setInt(1,auto.getIdmarca());
            pst.setInt(2,auto.getIdmodelo());
            pst.setInt(3,auto.getIdversion());
            pst.setInt(4,auto.getAnio());
            pst.setFloat(5,auto.getPrecio());
            pst.setInt(6,auto.getKilometros());
            pst.setString(7,auto.getCombustible());
            pst.setInt(8,auto.getPuertas());            
            pst.setString(9,auto.getCondicion());
            pst.setInt(10,auto.getIdauto());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar el auto" + e);
            return false;
        }
    }

    //Borrar auto
    public boolean borrarAuto(int id){
        
        System.out.println("en ModeloDao query BORRAR linea 95");
        String query = "DELETE FROM auto WHERE idauto = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar el auto" + e);
            return false;
        }
    }

    //Listar auto
    public List listarAuto(){
        
        System.out.println("en AutoDao query LISTAR linea 111");
        List<Auto> list_autos = new ArrayList();
        String query = "SELECT au.idauto, ma.nombre_marca, mo.nombre_modelo, ver.nombre_version,au.anio,"
                + " au.precio, au.kilometros, au.combustible, au.puertas, au.condicion"
                + " FROM auto as au INNER JOIN marca as ma ON au.idmarca = ma.idmarca"
                + " INNER JOIN modelo as mo ON au.idmodelo = mo.idmodelo"
                + " INNER JOIN version as ver ON au.idversion = ver.idversion "
                + " ORDER BY au.idauto DESC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Auto auto = new Auto();
                auto.setIdauto(rs.getInt("idauto"));
                auto.setNombre_marca(rs.getString("nombre_marca"));
                auto.setNombre_modelo(rs.getString("nombre_modelo"));
                auto.setNombre_version(rs.getString("nombre_version"));
                auto.setAnio(rs.getInt("anio"));
                auto.setPrecio(rs.getFloat("precio"));
                auto.setKilometros(rs.getInt("kilometros"));
                auto.setCombustible(rs.getString("combustible"));
                auto.setPuertas(rs.getInt("puertas"));
                auto.setCondicion(rs.getString("condicion"));
                
                list_autos.add(auto);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_autos;
    }    
    
    public List listarAutoFiltrar(String marcabuscar){
        List<Auto> list_autos = new ArrayList();
        String query = "SELECT ma.nombre_marca, mo.nombre_modelo, ver.nombre_version, au.anio,"
                + " au.precio, au.kilometros, au.combustible, au.puertas,au.condicion"
                + " FROM auto AS au INNER JOIN marca AS ma ON au.idmarca = ma.idmarca"
                + " INNER JOIN modelo AS mo ON au.idmodelo = mo.idmodelo"
                + " INNER JOIN version AS ver ON au.idversion = ver.idversion "
                + "WHERE au.marca LIKE '% "+ marcabuscar + "%'"
                + "ORDER BY nombre_marca ASC";     
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Auto auto = new Auto();
                //auto.setIdauto(rs.getInt("idauto")); // no utilizamos idauto en la tabla
                auto.setIdauto(rs.getInt("idauto"));
                auto.setNombre_marca(rs.getString("nombre_marca"));
                auto.setNombre_modelo(rs.getString("nombre_modelo"));
                auto.setNombre_version(rs.getString("nombre_version"));
                auto.setAnio(rs.getInt("anio"));
                auto.setPrecio(rs.getFloat("precio"));
                auto.setKilometros(rs.getInt("kilometros"));
                auto.setCombustible(rs.getString("combustible"));
                auto.setPuertas(rs.getInt("puertas"));
                auto.setCondicion(rs.getString("condicion"));
                list_autos.add(auto);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_autos;
    } 
    
    //Buscar id de version
    public int buscarIdauto(String nombre_version){
        int id = 0;
        String query = "SELECT idversion FROM version WHERE nombre_version = '" + nombre_version + "'";
        try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idversion");            
                System.out.println ("pase por versionDao linea 187 query SELECT buscarIdversion");
            }
        } catch (SQLException e) 
        { JOptionPane.showMessageDialog(null, "Error al buscar el id de version" + e);}
        return id;
        }
    
}