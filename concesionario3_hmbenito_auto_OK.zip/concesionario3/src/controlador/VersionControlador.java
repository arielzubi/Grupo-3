package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Marca;
import model.MarcaDao;
import model.Modelo;
import model.ModeloDao;
import model.Version;
import model.VersionDao;
import model.Auto;
import model.AutoDao;
import view.Panta_marca;
import view.Panta_modelo;
import view.Panta_auto;
import view.Panta_consulta;
import view.Panta_principal;
import view.Panta_version;

/**
 *
 * @author hmb
 */


public class VersionControlador implements ActionListener, MouseListener, KeyListener {
    private Marca marca;
    private MarcaDao marcaDao;
    private Modelo modelo;
    private ModeloDao modeloDao;
    private Version version;
    private VersionDao versionDao;
    private Auto auto;
    private AutoDao autoDao;
    private Panta_marca pantamarca;
    private Panta_modelo pantamodelo;
    private Panta_version panta;
    private Panta_auto pantaauto;
    private Panta_consulta pantaconsulta;
    private Panta_principal pantaprincipal;
    private int selector;
    
    DefaultTableModel model = new DefaultTableModel();

public VersionControlador(Panta_marca pantamarca,Panta_modelo pantamodelo, Panta_version panta,
        Panta_auto  pantaauto, Panta_consulta pantaconsulta, Marca marca, MarcaDao marcaDao,
        Modelo  modelo, ModeloDao modeloDao, Version version, VersionDao versionDao, Auto auto,
        AutoDao autoDao)
    {
        System.out.println("pase por VersionControlador linea 33");
        
         
        this.pantamarca = pantamarca;
        this.pantamodelo = pantamodelo;
        this.panta = panta;
        this.pantaauto = pantaauto;
        this.pantaconsulta = pantaconsulta;
        this.marca = marca;
        this.marcaDao = marcaDao;
        this.modelo = modelo;
        this.modeloDao = modeloDao;
        this.version = version;
        this.versionDao = versionDao;
        this.auto = auto;
        this.autoDao = autoDao;
       
        //Botón de registrar version
        this.panta.btn_agregar_version.addActionListener(this);
        //Botón de modificar version
        this.panta.btn_modificar_version.addActionListener(this);
        //Botón de borrar version
        this.panta.btn_borrar_version.addActionListener(this);
        //Botón de limpiar
        this.panta.btn_limpiar_version.addActionListener(this);

        this.panta.cbm_marca_version.addActionListener(this);
        this.panta.cbm_modelo_version.addActionListener(this);
        this.panta.txt_idversion.addActionListener(this);
        
        
        //Listado de version
        this.panta.tb_version.addMouseListener(this);
        
        System.out.println("pase por VersionControlador antes de listarVersiones linea 54");            
        listarVersiones(); 
        System.out.println("pase por VersionControlador despues de listarVersiones linea 54");
             
         this.panta.txt_version.addKeyListener(this);
         listarVersiones(); 
    }

      @Override
    public void actionPerformed(ActionEvent e) {
     if(e.getSource() == panta.btn_agregar_version){selector = 1;
        System.out.println("Agregar en Pantalla Modelo"+selector);
         System.out.println ("pase por autocontroller linea 62 agregar/modificar/borrar/limpiar/volver - SELECTOR " +selector);
        }
        else if(e.getSource() == panta.btn_modificar_version){selector = 2;
         System.out.println("Modificar en Pantalla Modelo" + selector);}
        else if(e.getSource() == panta.btn_borrar_version){selector = 3;
        System.out.println("Borrar en Pantalla Modelo" + selector);}
        else if(e.getSource() == panta.btn_limpiar_version){selector = 4;}
        else if(e.getSource() == panta.btn_volver_version){selector = 5;}
        
        
        System.out.println ("pase por autocontroller linea 87 agregar/modificar/borrar/limpiar/volver - SELECTOR " +selector);
        
    
        switch (selector){
           case 1: // AGREGAR -- seleccionamos en comboBox y verificamos seleccion
               {    //validamos la marca seleccionada, si la eleccion es erronea se va por el NO y termina el Switch liberando la rutina al inicio
               //if (e.getSource() != panta.cbm_marca_version)
                    {  {
                        boolean datosValidos = true;

                        JOptionPane.showMessageDialog(null,"Usted selecciono la marca " + panta.cbm_marca_version.getSelectedItem());
                               if (JOptionPane.showConfirmDialog(null,"Continua con la carga, [yes] para continuar"
                                       + "                       [No] para terminar, vuelva a elegir del combo",
                                       "[yes]",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
                                 { datosValidos = true;}
                                else {break;}
                        
                        datosValidos = false;}
                    //validamos el modelo seleccionado, si la eleccion es erronea se va por el NO y termina el Switch liberando la rutina al inicio
                    if (e.getSource() != panta.cbm_modelo_version){
                        boolean datosValidos = true;
                        JOptionPane.showMessageDialog(null,"Usted selecciono el modelo " + panta.cbm_modelo_version.getSelectedItem());
                               if (JOptionPane.showConfirmDialog(null,"Continua con la carga, [yes] para continuar"
                                       + "                       [No] para terminar, vuelva a elegir del combo",
                                       "[yes]",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
                                 { datosValidos = true;}
                                else {break;}
                        
                        datosValidos = false;}
                    }
               boolean datosValidos = true;
               do 
                   if (panta.txt_version.getText().trim().equals("")) {
                          String nombre_version = JOptionPane.showInputDialog("Ingrese la version:");
                          
                          System.out.println ("pase por versioncontroller linea 128 version = " + nombre_version);
                          
                           panta.txt_version.setText(nombre_version);
                                     
                        if (panta.txt_version.getText().equals("")) {datosValidos = false;}
                        else {
                               if (JOptionPane.showConfirmDialog(null,"Continua con la carga",
                                       "[yes]",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
                                 { datosValidos = true;}
                                else {datosValidos = false;}
                             }
               }    
                while (datosValidos != true);
                
                ModeloDao modeloDao = new ModeloDao();
                int idmodelo = modeloDao.buscarIdmodelo(String.valueOf(panta.cbm_modelo_version.getSelectedItem()));
             
                version.setNombre_version(panta.txt_version.getText());
                version.setIdmodelo(idmodelo);
                System.out.println ("pase por versioncontroller linea 150 sali del loop de control txt_version "
                        + version + "idmodelo = "+idmodelo);
              
                if(versionDao.agregarNombre_version(version)){
                    limpiarTabla();
                    limpiarCampos();
                    listarVersiones();
                    JOptionPane.showMessageDialog(null, "Se agrego la version");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar la version");
                    }
                System.out.println ("pase por versionController linea 160 Metodo AGREGAR");
                 panta.btn_agregar_version.setEnabled(true);
            }
            break;
                
                
            case 2:  // MODIFICAR -- seleccionamos en comboBox y verificamos seleccion
               { if (panta.txt_version.getText().trim().equals("")) {
                          JOptionPane.showMessageDialog(null,"Seleccione un registro de la Tabla");
                          
                          System.out.println ("pase por versioncontroller linea 147" );
                            
                         break;}
                    //llamamos al metodo DAO para buscar
                    // recuperamos los idmarca y idversion para la modificacion
                    
                    int idversion = versionDao.buscarIdversion(String.valueOf(panta.cbm_modelo_version.getSelectedItem()));
                     int idmarca = marcaDao.buscarIdmarca(String.valueOf(panta.cbm_marca_version.getSelectedItem())); 
                    int idmodelo = modeloDao.buscarIdmodelo(String.valueOf(panta.cbm_modelo_version.getSelectedItem())); 
                  
                    String versionActualizada = JOptionPane.showInputDialog("Por favor actualice el Modelo");
                    panta.txt_version.setText(versionActualizada);
                    
                    System.out.println ("pase por versionController linea 160 Metodo MODIFICAR idversion = " + idversion);
                    // guardamos atributos en version
                    version.setIdversion(idversion);
                    version.setNombre_version(panta.txt_version.getText());
                    version.setIdmodelo(idmodelo);
                    version.setIdmarca(idmarca);
                     //Realiza la modificacion en base de datos
                if (versionDao.modificarNombre_version (version)){
                    limpiarTabla();
                    limpiarCampos();
                    listarVersiones();
                    JOptionPane.showMessageDialog(null, "Se modifico el version");
                } else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el version");
                    }
                
            System.out.println ("pase por versionController linea 175 Metodo MODIFICAR");
                panta.btn_agregar_version.setEnabled(true);
            }
            break;
                

            case 3:   //BORRAR version
                { if(panta.txt_version.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
                    } else{
                          //Realiza el borrado

                         int id = versionDao.buscarIdversion(panta.txt_version.getText());   
                      
                      if(versionDao.borrarNombre_version(id)){
                          limpiarTabla();
                          limpiarCampos();
                          listarVersiones();
                          JOptionPane.showMessageDialog(null, "Se eliminó la version");
                            } else{
                            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar la version");
                            }
            System.out.println ("pase por versioncontroller linea 170 Metodo BORRAR");
                     }
                      panta.btn_agregar_version.setEnabled(true);
                }
            break;
                
            case 4:
                        //IMPIAAR y volver a Realizas el listado
                    {   limpiarTabla();
                        limpiarCampos();
                        listarVersiones();  
                        panta.btn_agregar_version.setEnabled(true);
                    }
            break;
            default :
            { System.out.println ("pase por versionController linea 164 Default Switch");}
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
            if(e.getSource() == panta.cbm_marca_version){
            int idversion = versionDao.buscarIdversion(panta.txt_version.getText());
            panta.txt_idversion.setText(Integer.toString(idversion));
            int row = panta.tb_version.rowAtPoint(e.getPoint());
            panta.txt_idversion.setText(panta.tb_version.getValueAt(row,4).toString());
            panta.txt_version.setText(panta.tb_version.getValueAt(row,3).toString());
            panta.cbm_marca_version.setSelectedItem(panta.tb_version.getValueAt(row,1).toString());
            panta.cbm_modelo_version.setSelectedItem(panta.tb_version.getValueAt(row,2).toString());
            } else {
            if(e.getSource() == panta.cbm_modelo_version){
            int idversion = versionDao.buscarIdversion(panta.txt_version.getText());
            panta.txt_idversion.setText(Integer.toString(idversion));
            int row = panta.tb_version.rowAtPoint(e.getPoint());
            panta.txt_idversion.setText(panta.tb_version.getValueAt(row,4).toString());
            panta.txt_version.setText(panta.tb_version.getValueAt(row,3).toString());
            panta.cbm_marca_version.setSelectedItem(panta.tb_version.getValueAt(row,1).toString());
            panta.cbm_modelo_version.setSelectedItem(panta.tb_version.getValueAt(row,2).toString());
            }
            }
            //Deshabilitar
            panta.btn_agregar_version.setEnabled(false);
    }
    
    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e){     
              int idmodelo = versionDao.buscarIdversion(panta.txt_version.getText());
            panta.txt_idversion.setText(Integer.toString(idmodelo));
            int row = panta.tb_version.rowAtPoint(e.getPoint());
            
            panta.txt_version.setText(panta.tb_version.getValueAt(row,2).toString());
             panta.cbm_marca_version.setSelectedItem(panta.tb_version.getValueAt(row,0).toString());
            panta.cbm_modelo_version.setSelectedItem(panta.tb_version.getValueAt(row,1).toString());
            
            //Deshabilitar
            panta.btn_agregar_version.setEnabled(false);}
    
   
    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getSource().equals( panta.txt_version))
            limpiarTabla();
            listarVersiones();
    }
 
        public void listarVersiones(){
       
        if (panta.txt_version.getText().equals("")){
        List<Version> list = versionDao.listarNombre_version();
        model = (DefaultTableModel) panta.tb_version.getModel();
        Object[] row = new Object[3];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            //row[0] = list.get(i).getIdversion(); // no tenemos idversion para mostrar en la tabla
            row[0] = list.get(i).getNombre_marca();
            row[1] = list.get(i).getNombre_modelo();
            row[2] = list.get(i).getNombre_version();
            pantaauto.cmb_version.addItem(list.get(i).getNombre_version());
        model.addRow(row);
        }
    }
 }

    //Limpiar la tabla
    public void limpiarTabla (){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_idversion.setText("");
        panta.txt_version.setText("");
  }
    
    
}
