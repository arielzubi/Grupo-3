package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import model.Marca;
import model.MarcaDao;
import model.Modelo;
import model.ModeloDao;
import model.Version;
import model.VersionDao;
import model.Auto;
import model.AutoDao;
import view.Panta_marca;
import view.Panta_modelo;
import view.Panta_auto;
import view.Panta_version;
import view.Panta_principal;
import javax.swing.SwingWorker;
import view.Panta_consulta;


/**
 *
 * 
 * @author hmb
 */

public class MarcaControlador implements ActionListener, MouseListener, KeyListener {
    private Marca marca;
    private MarcaDao marcaDao;
    private Modelo modelo;
    private ModeloDao modeloDao;
    private Version version;
    private VersionDao versionDao;
    private Auto auto;
    private AutoDao autoDao;
    private Panta_marca panta;
    private Panta_modelo pantamodelo;
    private Panta_version pantaversion;
    private Panta_auto pantaauto;
    private Panta_consulta pantaconsulta;
    
    private int selector;
    private String seleccion;
    
    DefaultTableModel model = new DefaultTableModel();
  
    public MarcaControlador(Panta_marca panta,Panta_modelo pantamodelo, Panta_version pantaversion,
            Panta_auto pantaauto, Panta_consulta pantaconsulta, Marca marca, MarcaDao marcaDao,
            Modelo  modelo, ModeloDao modeloDao, Version version, VersionDao versionDao, Auto auto,
            AutoDao autoDao){
        
        System.out.println("pase por MarcaControlador linea 45");
         
         
            this.panta = panta;
            this.pantamodelo = pantamodelo;
            this.pantaversion = pantaversion;
            this.pantaauto = pantaauto;
            this.pantaconsulta = pantaconsulta;
            this.marca = marca;
            this.marcaDao = marcaDao;
            this.modelo = modelo;
            this.modeloDao = modeloDao;
            this.version = version;
            this.versionDao = versionDao;
            this.auto = auto;
            this.autoDao = autoDao;

        //Botón de registrar marca
        this.panta.btn_agregar_marca.addActionListener(this);
        System.out.println("Listener registrado: btn_agregar_marca");
        //Botón de modificar marca
        this.panta.btn_modificar_marca.addActionListener(this);
        System.out.println("Listener registrado: btn_modificar_marca");
        //Botón de borrar marca
        this.panta.btn_borrar_marca.addActionListener(this);
        System.out.println("Listener registrado: btn_borrar_marca");
        //Botón de limpiar
        this.panta.btn_limpiar_marca.addActionListener(this);
                System.out.println("Listener registrado: btn_limpiar_marca");
        this.pantamodelo.cbm_marca_modelo.addActionListener(this);
        //Listado de marca
        this.panta.tb_marca.addMouseListener(this);
       System.out.println("pase por MarcaControlador linea 73 antes de listarMarcas");      
        listarMarcas(); 
        this.panta.txt_marca.addKeyListener(this);
         System.out.println("pase por MarcaControlador linea 76 despues de listarMarcas");  
         listarMarcas(); 
         
         
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        
        if(e.getSource() == panta.btn_agregar_marca){selector = 1;
        System.out.println("Agregar en Pantalla Marca"+selector);
         System.out.println ("pase por marcaontroller linea 88 agregar/modificar/borrar/limpiar/volver - SELECTOR " +selector);
        }
        else if(e.getSource() == panta.btn_modificar_marca){selector = 2;
         System.out.println("Agregar en Pantalla Modificar" + selector);}
        else if(e.getSource() == panta.btn_borrar_marca){selector = 3;
        System.out.println("Agregar en Pantalla Borrar" + selector);}
        else if(e.getSource() == panta.btn_limpiar_marca){selector = 4;}
        else if(e.getSource() == panta.btn_volver_marca){selector = 5;}
        
        
        System.out.println ("pase por marcaontroller linea 98 agregar/modificar/borrar/limpiar/volver - SELECTOR " +selector);
        
    
        switch (selector){
            case 1: // AGREGAR -- seleccionamos en comboBox y verificamos seleccion
               { // verificamos que los TXT_Field esten completos
                boolean datosValidos = true;
                
             
               do 
                   if (panta.txt_marca.getText().trim().equals("")) {
                          String nombre_marca = JOptionPane.showInputDialog("Ingrese la Marca:");
                          
                          System.out.println ("pase por marcacontroller linea 111 marca = " + nombre_marca);
                          
                           panta.txt_marca.setText(nombre_marca);
                                     
                        if (panta.txt_marca.getText().equals("")) {datosValidos = false;}
                        else {
                               if (JOptionPane.showConfirmDialog(null,"Continua con la carga",
                                       "[yes]",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
                                 { datosValidos = true;}
                                else {datosValidos = false;}
                             }
               }    
                while (datosValidos != true);
                  marca.setNombre_marca(panta.txt_marca.getText());
                System.out.println ("pase por marcacontroller linea 125 sali del loop de control txt_marca" + marca );
                                         
                if(marcaDao.agregarNombre_marca(marca)){
                    limpiarTabla();
                    limpiarCampos();
                    listarMarcas();
                    JOptionPane.showMessageDialog(null, "Se agrego la marca");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar la marca");
                    }
                System.out.println ("pase por marcaController linea 135 Metodo AGREGAR");
                 panta.btn_agregar_marca.setEnabled(true);
            }
            break;

            case 2:  // MODIFICAR -- seleccionamos en comboBox y verificamos seleccion
               {   if (panta.txt_marca.getText().trim().equals("")) {
                          JOptionPane.showMessageDialog(null,"Seleccione un registro de la Tabla");
                          
                          System.out.println ("pase por marcacontroller linea 144" );
                            
                         break;}
               
                //Realiza la modificacion
                    MarcaDao marcaDao = new MarcaDao();
                    //llamamos al metodo en DAO para buscar
                    int idmarca = marcaDao.buscarIdmarca(panta.txt_marca.getText());
                    String marcaActualizada = JOptionPane.showInputDialog("Por favor actualice la Marca");
                    panta.txt_marca.setText(marcaActualizada);
                    
                    System.out.println ("pase por marcaController linea 155 Metodo MODIFICAR idmarca = " + idmarca);
                    marca.setIdmarca(idmarca);
                    marca.setNombre_marca(panta.txt_marca.getText());
                     
                if(marcaDao.modificarNombre_marca(marca)){
                    limpiarTabla();
                    limpiarCampos();
                    listarMarcas();
                    JOptionPane.showMessageDialog(null, "Se modifico la marca");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el marca");
                    }
                
            System.out.println ("pase por marcaontroller linea 168 Metodo MODIFICAR");
                panta.btn_agregar_marca.setEnabled(true);
            }
            break;

            case 3:   //BORRAR marca
                { if(panta.txt_marca.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
                    } else{
                          //Realiza el borrado

                         int id = marcaDao.buscarIdmarca(panta.txt_marca.getText());   
                      
                      if(marcaDao.borrarNombre_marca(id)){
                          limpiarTabla();
                          limpiarCampos();
                          listarMarcas();
                          JOptionPane.showMessageDialog(null, "Se eliminó la marca");
                            } else{
                            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar la marca");
                            }
            System.out.println ("pase por marcacontroller linea 189 Metodo BORRAR");
                     }
                      panta.btn_agregar_marca.setEnabled(true);
                }
            break;
                
            case 4: //IMPIAAR y volver a Realizas el listado
                     limpiarTabla();
                     limpiarCampos();
                     listarMarcas();  
                     panta.btn_agregar_marca.setEnabled(true);
                   
            break;
            default :
            { System.out.println ("pase por marcaontroller linea 203 Default Switch");}
        }
    }   
    

    @Override
    public void mouseClicked(MouseEvent e) {
                if(e.getSource() == panta.txt_marca){
            MarcaDao marcaDao = new MarcaDao();
            int idmodelo = marcaDao.buscarIdmarca(panta.txt_marca.getText());
            panta.txt_idmarca.setText(Integer.toString(idmodelo));        
            int row = panta.tb_marca.rowAtPoint(e.getPoint());
                       
            panta.txt_marca.setText(panta.tb_marca.getValueAt(row,0).toString());
            
            int idmarca = marcaDao.buscarIdmarca(panta.txt_marca.toString());
            
            panta.txt_idmarca.setText(String.valueOf(idmarca));
            System.out.println ("pase por marcaontroller mouseClicked linea 221");
            
            //Deshabilitar
            panta.btn_agregar_marca.setEnabled(false);
        }
    }
    @Override
    public void mousePressed(MouseEvent e) {
    }

    
    @Override
    public void mouseReleased(MouseEvent e) {
        
        boolean seleccion = true;
        if(e.getSource() == panta.tb_marca){
            int idmodelo = marcaDao.buscarIdmarca(panta.txt_marca.getText());
            panta.txt_idmarca.setText(Integer.toString(idmodelo));
            int row = panta.tb_marca.rowAtPoint(e.getPoint());
            panta.txt_marca.setText(panta.tb_marca.getValueAt(row,0).toString());

            //Deshabilitar
            panta.btn_agregar_marca.setEnabled(false);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getSource().equals( panta.txt_marca))
            limpiarTabla();
            listarMarcas();
    }
 
        public void listarMarcas(){
       
        if (panta.txt_marca.getText().equals("")){
        List<Marca> list = marcaDao.listarNombre_marca();
        model = (DefaultTableModel) panta.tb_marca.getModel();
        Object[] row = new Object[1];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getNombre_marca();
            pantamodelo.cbm_marca_modelo.addItem(list.get(i).getNombre_marca());
            pantaversion.cbm_marca_version.addItem(list.get(i).getNombre_marca());
            pantaauto.cmb_marca.addItem(list.get(i).getNombre_marca());
        model.addRow(row);
        }
    }
 }

    //Limpiar la tabla
    public void limpiarTabla (){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_idmarca.setText("");
        panta.txt_marca.setText("");
  }
}