package concesionaria;

import view.Panta_principal;

/**
 *
 * @author lucas
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Panta_principal panta = new Panta_principal();
        panta.setVisible(true);
        System.out.println ("pase por Main linea 17");
    }
    
}
