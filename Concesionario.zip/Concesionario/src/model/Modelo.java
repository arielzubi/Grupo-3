
package model;


public class Modelo {
    
    private int idmodelo;
    private String nombre_modelo;
    private String nombre_marca;

    public Modelo() {
    }

    public Modelo(int idmodelo, String nombre_modelo, String nombre_marca) {
        this.idmodelo = idmodelo;
        this.nombre_modelo = nombre_modelo;
        this.nombre_marca = nombre_marca;
    }

    public int getIdmodelo() {
        return idmodelo;
    }

    public void setIdmodelo(int idmodelo) {
        this.idmodelo = idmodelo;
    }

    public String getNombre_modelo() {
        return nombre_modelo;
    }

    public void setNombre_modelo(String nombre_modelo) {
        this.nombre_modelo = nombre_modelo;
    }

    public String getNombre_marca() {
        return nombre_marca;
    }

    public void setNombre_marca(String nombre_marca) {
        this.nombre_marca = nombre_marca;
    }

    @Override
    public String toString() {
        return "Modelo{" + "idmodelo=" + idmodelo + ", nombre_modelo=" + nombre_modelo + ", nombre_marca=" + nombre_marca + '}';
    }

    
    
    
    
}
