
package model;


public class Auto {
    
    private int idauto;
    private int idmarca;
    private String nombre_marca;
    private int idmodelo;
    private String nombre_modelo;
    private int idversion;
    private String nombre_version;
    private int anio;
    private float precio;
    private int kilometros;
    private String combustible;
    private int puertas;
    private String condicion;

    public Auto() {
    }

    public Auto(int idauto, int idmarca, String nombre_marca, int idmodelo, String nombre_modelo, int idversion, String nombre_version, int anio, float precio, int kilometros, String combustible, int puertas, String condicion) {
        this.idauto = idauto;
        this.idmarca = idmarca;
        this.nombre_marca = nombre_marca;
        this.idmodelo = idmodelo;
        this.nombre_modelo = nombre_modelo;
        this.idversion = idversion;
        this.nombre_version = nombre_version;
        this.anio = anio;
        this.precio = precio;
        this.kilometros = kilometros;
        this.combustible = combustible;
        this.puertas = puertas;
        this.condicion = condicion;
    }

    public int getIdauto() {
        return idauto;
    }

    public void setIdauto(int idauto) {
        this.idauto = idauto;
    }

    public int getIdmarca() {
        return idmarca;
    }

    public void setIdmarca(int idmarca) {
        this.idmarca = idmarca;
    }

    public String getNombre_marca() {
        return nombre_marca;
    }

    public void setNombre_marca(String nombre_marca) {
        this.nombre_marca = nombre_marca;
    }

    public int getIdmodelo() {
        return idmodelo;
    }

    public void setIdmodelo(int idmodelo) {
        this.idmodelo = idmodelo;
    }

    public String getNombre_modelo() {
        return nombre_modelo;
    }

    public void setNombre_modelo(String nombre_modelo) {
        this.nombre_modelo = nombre_modelo;
    }

    public int getIdversion() {
        return idversion;
    }

    public void setIdversion(int idversion) {
        this.idversion = idversion;
    }

    public String getNombre_version() {
        return nombre_version;
    }

    public void setNombre_version(String nombre_version) {
        this.nombre_version = nombre_version;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public int getKilometros() {
        return kilometros;
    }

    public void setKilometros(int kilometros) {
        this.kilometros = kilometros;
    }

    public String getCombustible() {
        return combustible;
    }

    public void setCombustible(String combustible) {
        this.combustible = combustible;
    }

    public int getPuertas() {
        return puertas;
    }

    public void setPuertas(int puertas) {
        this.puertas = puertas;
    }

    public String getCondicion() {
        return condicion;
    }

    public void setCondicion(String condicion) {
        this.condicion = condicion;
    }

    @Override
    public String toString() {
        return "Auto{" + "idauto=" + idauto + ", idmarca=" + idmarca + ", nombre_marca=" + nombre_marca + ", idmodelo=" + idmodelo + ", nombre_modelo=" + nombre_modelo + ", idversion=" + idversion + ", nombre_version=" + nombre_version + ", anio=" + anio + ", precio=" + precio + ", kilometros=" + kilometros + ", combustible=" + combustible + ", puertas=" + puertas + ", condicion=" + condicion + '}';
    }

    
    

}