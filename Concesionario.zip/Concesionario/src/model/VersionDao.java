package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class VersionDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public VersionDao() {
    }
    //Agregar Version
    public boolean agregarVersion(Version version){
        String query = "INSERT INTO version (idversion) VALUES(?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setInt(0,version.getIdversion());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar el Version" + e);
            return false;
        }
    }
    
    //Modificar auto
    public boolean modificarVersion(Version version){
        String query = "UPDATE version SET idversion = ? WHERE idversion = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setInt(2, version.getIdversion());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar el Version" + e);
            return false;
        }
    }

    //Borrar auto
    public boolean borrarVersion(int id){
        String query = "DELETE FROM auto WHERE idversion = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar el Version" + e);
            return false;
        }
    }

    //Listar auto
    public List listarVersion(){
        List<Version> list_Versiones = new ArrayList();
        String query = "SELECT au.*, ma.nombre_marca, mo.nombre_modelo, ve.nombre_version FROM auto as au inner join marca as ma on au.idmarca = ma.idmarca inner join modelo as mo on au.idmodelo = mo.idmodelo inner join version as ve on au.idversion = ve.idversion ORDER BY nombre_marca ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Version version = new Version();
                version.setIdversion(rs.getInt("idversion"));
                version.setNombre_marca(rs.getString("nombre_marca"));
                version.setNombre_modelo(rs.getString("nombre_modelo"));
                version.setNombre_version(rs.getString("nombre_version"));
                        
                list_Versiones.add(version);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_Versiones;
    }    
    
    //Buscar id de auto
    public int buscarIdversion(String nombre){
        int id = 0;
        String query = "SELECT idversion FROM Version WHERE idversion = '" + nombre + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idversion");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de Version" + e);
        }
        return id;
    }

}