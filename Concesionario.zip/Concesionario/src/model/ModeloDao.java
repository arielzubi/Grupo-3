package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ModeloDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public ModeloDao() {
    }
    //Agregar Version
    public boolean agregarModelo(Modelo modelo){
        String query = "INSERT INTO modelo (nombre_modelo) VALUES(?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,modelo.getNombre_modelo());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar el Modelo" + e);
            return false;
        }
    }
    
    //Modificar auto
    public boolean modificarModelo(Modelo modelo){
        String query = "UPDATE modelo SET nombre_modelo = ? WHERE idmodelo = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,modelo.getNombre_modelo());
            pst.setInt(2, modelo.getIdmodelo());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar el Modelo" + e);
            return false;
        }
    }

    //Borrar auto
    public boolean borrarModelo(int id){
        String query = "DELETE FROM modelo WHERE idmodelo = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar el modelo" + e);
            return false;
        }
    }

    //Listar auto
    public List listarModelo(){
        List<Modelo> list_Modelos = new ArrayList();
        String query = "SELECT *, ma.idmarca, mo.idmodelo, mo.nombre_modelo, ma.nombre_marca FROM modelo as mo inner join marca as ma on mo.idmarca = ma.idmarca ORDER BY nombre_modelo ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Modelo modelo = new Modelo();
                modelo.setIdmodelo(rs.getInt("idmodelo"));
                modelo.setNombre_modelo(rs.getString("nombre_modelo"));
                modelo.setNombre_marca(rs.getString("nombre_marca"));
                list_Modelos.add(modelo);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_Modelos;
    }    
    
    //Buscar id de auto
    public int buscarIdmodelo(String nombre){
        int id = 0; //"SELECT idauto FROM auto WHERE idauto = '" + nombre + "'";
        String query = "SELECT idmodelo FROM modelo where idmodelo = '" + nombre + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idmodelo");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id del modelo" + e);
        }
        return id;
    }

}
