
package model;


public class Version {
    
    private int idversion;
    private String nombre_version;
    private String nombre_marca;
    private String nombre_modelo;

    public Version() {
    }

    public Version(int idversion, String nombre_version, String nombre_marca, String nombre_modelo) {
        this.idversion = idversion;
        this.nombre_version = nombre_version;
        this.nombre_marca = nombre_marca;
        this.nombre_modelo = nombre_modelo;
    }

    public int getIdversion() {
        return idversion;
    }

    public void setIdversion(int idversion) {
        this.idversion = idversion;
    }

    public String getNombre_version() {
        return nombre_version;
    }

    public void setNombre_version(String nombre_version) {
        this.nombre_version = nombre_version;
    }

    public String getNombre_marca() {
        return nombre_marca;
    }

    public void setNombre_marca(String nombre_marca) {
        this.nombre_marca = nombre_marca;
    }

    public String getNombre_modelo() {
        return nombre_modelo;
    }

    public void setNombre_modelo(String nombre_modelo) {
        this.nombre_modelo = nombre_modelo;
    }

    @Override
    public String toString() {
        return "Version{" + "idversion=" + idversion + ", nombre_version=" + nombre_version + ", nombre_marca=" + nombre_marca + ", nombre_modelo=" + nombre_modelo + '}';
    }

    
    
}
