package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Modelo;
import model.ModeloDao;
import model.Version;
import model.VersionDao;
import view.Panta_auto;
import view.Panta_consulta;
import view.Panta_marca;
import view.Panta_modelo;
import view.Panta_version;

public class ModeloControlador implements ActionListener, MouseListener, KeyListener {
    
    private Modelo modelo;
    private ModeloDao modeloDao;
    private Panta_modelo panta;
    private Panta_marca pantama;

    DefaultTableModel model = new DefaultTableModel();

    public ModeloControlador(Modelo modelo, ModeloDao modeloDao, Panta_modelo panta) {
        this.modelo = modelo;
        this.modeloDao = modeloDao;
        this.panta = panta;
        
        //Botón de registrar auto
        this.panta.btn_agregar_modelo.addActionListener(this);
        //Botón de modificar auto
        this.panta.btn_modificar_modelo.addActionListener(this);
        //Botón de borrar auto
        this.panta.btn_borrar_modelo.addActionListener(this);
        //Botón de limpiar
        this.panta.btn_limpiar_modelo.addActionListener(this);
        
        //Listado de Version
        this.panta.tb_modelo.addMouseListener(this);
              
        listarModelos(); 
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
            if(e.getSource() == panta.btn_agregar_modelo){
            //verifica si el campo nombre está vacío
            if(panta.txt_modelo.getText().equals("")){
                JOptionPane.showMessageDialog(null, "El campo modelo es obligatorio");
            }else{
                //Realiza el agregado
                modelo.setNombre_modelo(panta.txt_modelo.getText());
                if(modeloDao.agregarModelo(modelo)){
                    limpiarTabla();
                    limpiarCampos();
                    listarModelos();
                    JOptionPane.showMessageDialog(null, "Se agregó el modelo");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar el modelo");
                }
            }
        }else if(e.getSource() == panta.btn_modificar_modelo){
            //verifica si el campo id está vacío
            if(panta.txt_modelo.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza la modificación
                modelo.setNombre_modelo(panta.txt_modelo.getText());
                
                if(modeloDao.modificarModelo(modelo)){
                    limpiarTabla();
                    limpiarCampos();
                    listarModelos();
                    JOptionPane.showMessageDialog(null, "Se modificó el modelo");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el modelo");
                }
            }
        }else if(e.getSource() == panta.btn_borrar_modelo){
            //verifica si el campo id está vacío
            if(panta.txt_modelo.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza el borrado
                int id = Integer.parseInt(panta.txt_modelo.getText());
                if(modeloDao.borrarModelo(id)){
                    limpiarTabla();
                    limpiarCampos();
                    listarModelos();
                    JOptionPane.showMessageDialog(null, "Se eliminó el modelo");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar el modelo");
                }
            }
        }else if(e.getSource() == panta.btn_limpiar_modelo){
                limpiarTabla();
                limpiarCampos();
                listarModelos();    
                panta.btn_agregar_modelo.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getSource().equals(panta.txt_modelo))
            limpiarTabla();
            listarModelos();
    }

    //Listar todos los autoes
    public void listarModelos(){

        panta.txt_modelo.setText("");        
        
        List<Modelo> list = modeloDao.listarModelo();
        model = (DefaultTableModel) panta.tb_modelo.getModel();
        Object[] row = new Object[2];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getNombre_modelo();
            model.addRow(row);
            panta.txt_modelo.setText(list.get(i).getNombre_modelo());
            panta.cmb_marca_modelo.addItem(list.get(i).getNombre_marca());
            
            
        }
    }


    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_modelo.setText("");
        
        
    }
    
}
