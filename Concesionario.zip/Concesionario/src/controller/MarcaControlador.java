package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Marca;
import model.MarcaDao;
import view.Panta_auto;
import view.Panta_consulta;
import view.Panta_marca;
import view.Panta_modelo;
import view.Panta_version;

public class MarcaControlador implements ActionListener, MouseListener, KeyListener {
    
    private Marca marca;
    private MarcaDao marcaDao;
    private Panta_marca panta;
   
   
    
    DefaultTableModel model = new DefaultTableModel();

    public MarcaControlador(Marca marca, MarcaDao marcaDao, Panta_marca panta ) {
        
        this.marca = marca;
        this.marcaDao = marcaDao;
        this.panta = panta;
        
        
        //Botón de registrar auto
        this.panta.btn_agregar_marca.addActionListener(this);
        //Botón de modificar auto
        this.panta.btn_modificar_marca.addActionListener(this);
        //Botón de borrar auto
        this.panta.btn_borrar_marca.addActionListener(this);
        //Botón de limpiar
        this.panta.btn_limpiar_marca.addActionListener(this);
        
        //Listado de Version
        this.panta.tb_marca.addMouseListener(this);
              
        listarMarcas(); 
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
            if(e.getSource() == panta.btn_agregar_marca){
            //verifica si el campo nombre está vacío
            if(panta.txt_marca.getText().equals("")){
                JOptionPane.showMessageDialog(null, "El campo marca es obligatorio");
            }else{
                //Realiza el agregado
                marca.setNombre_marca(panta.txt_marca.getText());
                if(marcaDao.agregarMarca(marca)){
                    limpiarTabla();
                    limpiarCampos();
                    listarMarcas();
                    JOptionPane.showMessageDialog(null, "Se agregó la marca");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar la marca");
                }
            }
        }else if(e.getSource() == panta.btn_modificar_marca){
            //verifica si el campo id está vacío
            if(panta.txt_marca.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza la modificación
                marca.setNombre_marca(panta.txt_marca.getText());
                
                if(marcaDao.modificarMarca(marca)){
                    limpiarTabla();
                    limpiarCampos();
                    listarMarcas();
                    JOptionPane.showMessageDialog(null, "Se modificó el auto");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el auto");
                }
            }
        }else if(e.getSource() == panta.btn_borrar_marca){
            //verifica si el campo id está vacío
            if(panta.txt_marca.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza el borrado
                int id = Integer.parseInt(panta.txt_idmarca.getText());
                if(marcaDao.borrarMarca(id)){
                    limpiarTabla();
                    limpiarCampos();
                    listarMarcas();
                    JOptionPane.showMessageDialog(null, "Se eliminó el auto");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar el auto");
                }
            }
        }else if(e.getSource() == panta.btn_limpiar_marca){
                limpiarTabla();
                limpiarCampos();
                listarMarcas();    
                panta.btn_agregar_marca.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
         if(e.getSource() == panta.tb_marca){
            int row = panta.tb_marca.rowAtPoint(e.getPoint());
            panta.txt_idmarca.setText(panta.tb_marca.getValueAt(row,0).toString());
            panta.txt_marca.setText(panta.tb_marca.getValueAt(row,1).toString());
            
        }       
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    //Listar todos los autoes
    public void listarMarcas(){

        panta.txt_marca.setText("");
        

        List<Marca> list = marcaDao.listarMarca();
        model = (DefaultTableModel) panta.tb_marca.getModel();
        Object[] row = new Object[2];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            
            row[0] = list.get(i).getIdmarca();
            row[1] = list.get(i).getNombre_marca();
            model.addRow(row);
        
           
            
            
            
        }
    }


    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_marca.setText("");
        panta.txt_idmarca.setText("");
        
        
    }
    
}
