package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Consulta;
import model.ConsultaDao;
import view.Panta_consulta;
import model.MarcaDao;
import model.ModeloDao;
import model.Version;
import model.VersionDao;



public class ConsultaControlador implements ActionListener, MouseListener, KeyListener {
    private Consulta consulta;
    private ConsultaDao consultaDao;
    private Panta_consulta panta;

    DefaultTableModel model = new DefaultTableModel();

    public ConsultaControlador(Consulta consulta, ConsultaDao consultaDao, Panta_consulta panta) {
        this.consulta = consulta;
        this.consultaDao = consultaDao;
        this.panta = panta;
        
        //Botón de registrar consulta
       
        
        //Listado de consulta
        this.panta.tb_consulta.addMouseListener(this);
        
        this.panta.txt_buscar.addKeyListener(this);
              
        listarConsultas(); 
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        
            if(panta.txt_buscar.getText().equals("")){
                JOptionPane.showMessageDialog(null, "El campo buscar es obligatorio");
            }else{
                //Realiza el agregado
                MarcaDao MarcaDao = new MarcaDao();
                int idmarca = MarcaDao.buscarIdmarca(panta.cmb_marca_consulta.getSelectedItem().toString());
                ModeloDao modeloDao = new ModeloDao();
                int idmodelo = modeloDao.buscarIdmodelo(panta.cmb_modelo_consulta.getSelectedItem().toString());
                VersionDao versionDao = new VersionDao();
                int idversion = versionDao.buscarIdversion(panta.cmb_version_consulta.getSelectedItem().toString());
                

                
                consulta.setIdmarca(idmarca);
                consulta.setIdmodelo(idmodelo);
                consulta.setIdversion(idversion);
              
                
                
            }
        }
               
    

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tb_consulta){
            int row = panta.tb_consulta.rowAtPoint(e.getPoint());
            

            panta.cmb_marca_consulta.setSelectedItem(panta.tb_consulta.getValueAt(row,0).toString());
            
            panta.cmb_modelo_consulta.setSelectedItem(panta.tb_consulta.getValueAt(row,1).toString());
            panta.cmb_version_consulta.setSelectedItem(panta.tb_consulta.getValueAt(row,2).toString());
            

            //Deshabilitar
            
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getSource() == panta.txt_buscar) {
            limpiarTabla();
            listarConsultas ();
           
        }
    }

    //Listar todos los Marcaes
    public void listarConsultas(){
        panta.cmb_marca_consulta.removeAllItems();
        panta.cmb_modelo_consulta.removeAllItems();
        panta.cmb_version_consulta.removeAllItems();
                
           if (panta.txt_buscar.getText().equals ("")) {     
        List<Consulta> list = consultaDao.listarConsulta();
       
         
        model = (DefaultTableModel) panta.tb_consulta.getModel();
        Object[] row = new Object[3];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            
            row[0] = list.get(i).getNombre_marca();
            row[1] = list.get(i).getNombre_modelo();
            row[2] = list.get(i).getNombre_version();
            model.addRow(row);
            
            panta.cmb_marca_consulta.addItem(list.get(i).getNombre_marca());
            panta.cmb_modelo_consulta.addItem(list.get(i).getNombre_modelo());
            panta.cmb_version_consulta.addItem(list.get(i).getNombre_version());
        }

         
           }else{
            
         String version = panta.txt_buscar.getText();
         List<Consulta> list = consultaDao.listarConsultaVer(version);  
         
        model = (DefaultTableModel) panta.tb_consulta.getModel();
        Object[] row = new Object[3];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getNombre_marca();
            row[1] = list.get(i).getNombre_modelo();
            row[2] = list.get(i).getNombre_version();
            
            model.addRow(row);
        }
    }

    }
    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        
        panta.txt_buscar.setText("");
        
    }
    
}
