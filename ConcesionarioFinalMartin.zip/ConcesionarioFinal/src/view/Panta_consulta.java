package view;



import model.Consulta;
import model.ConsultaDao;
import controller.ConsultaControlador;
import model.Marca;
import model.MarcaDao;
import controller.MarcaControlador;
import model.Modelo;
import model.ModeloDao;
import controller.ModeloControlador;
import model.Version;
import model.VersionDao;
import controller.VersionControlador;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;
import model.Conexion;

public class Panta_consulta extends javax.swing.JFrame {

        Consulta consulta = new Consulta();
        ConsultaDao consultaDao = new ConsultaDao();
        Marca marca = new Marca();
        MarcaDao marcaDao = new MarcaDao();
        Modelo modelo = new Modelo();
        ModeloDao modeloDao = new ModeloDao();
        Version version = new Version();
        VersionDao versionDao = new VersionDao();
     Conexion cn = new Conexion();
         Connection con;
        PreparedStatement pst;
        ResultSet rs;
    
    public Panta_consulta() {
        initComponents();
        setLocationRelativeTo(null);
       
        ConsultaControlador consultaControlador = new ConsultaControlador (consulta, consultaDao,this);
        consultaControlador.listarConsultas();
       
       
        
    cerrar();
        
    }
public void cerrar(){
    try {
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
        
            
            public void windowClosing(WindowEvent e) {
            confirmarsalida();
        
            }
    
    
             }   );
        }   catch (Exception e) {
        }
        }
    public void confirmarsalida( ){
        
        int valor=JOptionPane.showConfirmDialog
        (this, "¿Desea cerrar la aplicacion?", "Advertencia", JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
        if (valor==JOptionPane.YES_OPTION){
            
            JOptionPane.showMessageDialog(null, "HASTA LA VISTA", "", JOptionPane.INFORMATION_MESSAGE);
            System.exit(0);
        }
    }


    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cmb_marca_consulta = new javax.swing.JComboBox<>();
        cmb_modelo_consulta = new javax.swing.JComboBox<>();
        cmb_version_consulta = new javax.swing.JComboBox<>();
        lbl_marca_consulta = new javax.swing.JLabel();
        lbl_modelo_consulta = new javax.swing.JLabel();
        lbl_version_consulta = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_consulta = new javax.swing.JTable();
        btn_volver_consulta = new javax.swing.JButton();
        lbl_consulta = new javax.swing.JLabel();
        txt_buscar = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 51, 51));
        jLabel1.setText("CONSULTA");

        cmb_marca_consulta.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        cmb_marca_consulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_marca_consultaActionPerformed(evt);
            }
        });

        cmb_modelo_consulta.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        cmb_modelo_consulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_modelo_consultaActionPerformed(evt);
            }
        });

        cmb_version_consulta.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        cmb_version_consulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_version_consultaActionPerformed(evt);
            }
        });

        lbl_marca_consulta.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        lbl_marca_consulta.setForeground(new java.awt.Color(0, 51, 51));
        lbl_marca_consulta.setText("MARCA");

        lbl_modelo_consulta.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        lbl_modelo_consulta.setForeground(new java.awt.Color(0, 51, 51));
        lbl_modelo_consulta.setText("MODELO");

        lbl_version_consulta.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        lbl_version_consulta.setForeground(new java.awt.Color(0, 51, 51));
        lbl_version_consulta.setText("VERSION");

        tb_consulta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "MARCA", "MODELO", "VERSION"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tb_consulta);

        btn_volver_consulta.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        btn_volver_consulta.setText("VOLVER");
        btn_volver_consulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_volver_consultaActionPerformed(evt);
            }
        });

        lbl_consulta.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        lbl_consulta.setForeground(new java.awt.Color(0, 51, 51));
        lbl_consulta.setText("CONSULTA");

        txt_buscar.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        txt_buscar.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(lbl_marca_consulta, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmb_marca_consulta, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(lbl_modelo_consulta, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(cmb_modelo_consulta, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(31, 31, 31)
                .addComponent(lbl_version_consulta, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmb_version_consulta, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(269, 269, 269)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(196, 196, 196)
                        .addComponent(lbl_consulta, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(txt_buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 902, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_volver_consulta, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_consulta, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_buscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbl_marca_consulta, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmb_marca_consulta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cmb_modelo_consulta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmb_version_consulta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_modelo_consulta, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_version_consulta, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_volver_consulta, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_volver_consultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_volver_consultaActionPerformed
        dispose();
        Panta_principal panta = new Panta_principal();
        panta.setVisible(true);
      
    }//GEN-LAST:event_btn_volver_consultaActionPerformed

    private void cmb_marca_consultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_marca_consultaActionPerformed
    
    }//GEN-LAST:event_cmb_marca_consultaActionPerformed

    private void cmb_modelo_consultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_modelo_consultaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmb_modelo_consultaActionPerformed

    private void cmb_version_consultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_version_consultaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmb_version_consultaActionPerformed

    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btn_volver_consulta;
    public javax.swing.JComboBox<String> cmb_marca_consulta;
    public javax.swing.JComboBox<String> cmb_modelo_consulta;
    public javax.swing.JComboBox<String> cmb_version_consulta;
    public javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JLabel lbl_consulta;
    public javax.swing.JLabel lbl_marca_consulta;
    public javax.swing.JLabel lbl_modelo_consulta;
    public javax.swing.JLabel lbl_version_consulta;
    public javax.swing.JTable tb_consulta;
    public javax.swing.JTextField txt_buscar;
    // End of variables declaration//GEN-END:variables
}
