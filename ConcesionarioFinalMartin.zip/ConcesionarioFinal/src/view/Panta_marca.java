
package view;

import controller.MarcaControlador;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;
import model.Marca;
import model.MarcaDao;


public class Panta_marca extends javax.swing.JFrame {

    Marca marca = new Marca();
    MarcaDao marcaDao = new MarcaDao();   
        
    public Panta_marca() {
        initComponents();
        setLocationRelativeTo(null);
        
        MarcaControlador marcaControlador = new MarcaControlador (marca, marcaDao,this);
        marcaControlador.listarMarcas();
        
        
    cerrar();
        
    }
public void cerrar(){
    try {
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
        
            
            public void windowClosing(WindowEvent e) {
            confirmarsalida();
        
            }
    
    
             }   );
        }   catch (Exception e) {
        }
        }
    public void confirmarsalida( ){
        
        int valor=JOptionPane.showConfirmDialog
        (this, "¿Desea cerrar la aplicacion?", "Advertencia", JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
        if (valor==JOptionPane.YES_OPTION){
            
            JOptionPane.showMessageDialog(null, "HASTA LA VISTA", "", JOptionPane.INFORMATION_MESSAGE);
            System.exit(0);
        }
    }


   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lbl_marca = new javax.swing.JLabel();
        btn_agregar_marca = new javax.swing.JButton();
        btn_modificar_marca = new javax.swing.JButton();
        btn_borrar_marca = new javax.swing.JButton();
        btn_limpiar_marca = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_marca = new javax.swing.JTable();
        btn_volver_marca = new javax.swing.JButton();
        txt_marca = new javax.swing.JTextField();
        txt_idmarca = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 48)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("MARCA");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(286, 13, 252, 65));

        lbl_marca.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        lbl_marca.setForeground(new java.awt.Color(0, 51, 51));
        lbl_marca.setText("MARCA");
        jPanel2.add(lbl_marca, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 110, 88, 35));

        btn_agregar_marca.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_agregar_marca.setForeground(new java.awt.Color(0, 51, 51));
        btn_agregar_marca.setText("AGREGAR");
        jPanel2.add(btn_agregar_marca, new org.netbeans.lib.awtextra.AbsoluteConstraints(89, 191, -1, -1));

        btn_modificar_marca.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_modificar_marca.setForeground(new java.awt.Color(0, 51, 51));
        btn_modificar_marca.setText("MODIFICAR");
        jPanel2.add(btn_modificar_marca, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 190, -1, -1));

        btn_borrar_marca.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_borrar_marca.setForeground(new java.awt.Color(0, 51, 51));
        btn_borrar_marca.setText("BORRAR");
        jPanel2.add(btn_borrar_marca, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 190, -1, -1));

        btn_limpiar_marca.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_limpiar_marca.setForeground(new java.awt.Color(0, 51, 51));
        btn_limpiar_marca.setText("LIMPIAR");
        jPanel2.add(btn_limpiar_marca, new org.netbeans.lib.awtextra.AbsoluteConstraints(692, 191, -1, -1));

        tb_marca.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "MARCA"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tb_marca.setGridColor(new java.awt.Color(0, 0, 0));
        jScrollPane1.setViewportView(tb_marca);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 248, 810, 180));

        btn_volver_marca.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        btn_volver_marca.setText("VOLVER");
        btn_volver_marca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_volver_marcaActionPerformed(evt);
            }
        });
        jPanel2.add(btn_volver_marca, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 450, 143, 41));

        txt_marca.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_marca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_marcaActionPerformed(evt);
            }
        });
        jPanel2.add(txt_marca, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 114, 139, 31));

        txt_idmarca.setEditable(false);
        txt_idmarca.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel2.add(txt_idmarca, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 120, 33, -1));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 855, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 542, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_volver_marcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_volver_marcaActionPerformed
        dispose();
        Panta_principal panta = new Panta_principal();
        panta.setVisible(true);
    }//GEN-LAST:event_btn_volver_marcaActionPerformed

    private void txt_marcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_marcaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_marcaActionPerformed

    /**
     * @param args the command line arguments
     */
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btn_agregar_marca;
    public javax.swing.JButton btn_borrar_marca;
    public javax.swing.JButton btn_limpiar_marca;
    public javax.swing.JButton btn_modificar_marca;
    public javax.swing.JButton btn_volver_marca;
    public javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JLabel lbl_marca;
    public javax.swing.JTable tb_marca;
    public javax.swing.JTextField txt_idmarca;
    public javax.swing.JTextField txt_marca;
    // End of variables declaration//GEN-END:variables
}
