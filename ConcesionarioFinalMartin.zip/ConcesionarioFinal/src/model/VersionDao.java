package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import view.Panta_auto;
import view.Panta_modelo;
import view.Panta_version;

public class VersionDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public VersionDao() {
    }
    //Agregar Version
    public boolean agregarVersion(Version version){
        String query = "INSERT INTO version (nombre_version, idmodelo, idmarca) VALUES(?,?,?)";
        
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,version.getNombre_version());
            pst.setInt(2,version.getIdmodelo());
            pst.setInt(3,version.getIdmarca());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar el Version" + e);
            return false;
        }
    }
    
    //Modificar auto
    public boolean modificarVersion(Version version){
        String query = "UPDATE version SET nombre_version = ?, idmodelo = ?, idmarca = ? WHERE idversion = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1, version.getNombre_version());
            pst.setInt(2, version.getIdmodelo());
            pst.setInt(3, version.getIdmarca());
            pst.setInt(4, version.getIdversion());
            System.out.println(pst);
            pst.execute();
            
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar el Version" + e);
            return false;
        }
    }

    //Borrar auto
    public boolean borrarVersion(int id){
        String query = "DELETE FROM version WHERE idversion = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar el Version" + e);
            return false;
        }
    }

    //Listar auto
    public List listarVersion(){
        List<Version> list_Versiones = new ArrayList();
                     
        String query = "SELECT *, ma.idmarca, ma.nombre_marca, mo.idmodelo, mo.nombre_modelo, ve.nombre_version, ve.idversion FROM version as ve inner join marca as ma on ve.idmarca = ma.idmarca inner join modelo as mo on ve.idmodelo = mo.idmodelo ORDER BY nombre_version ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Version version = new Version();
                version.setIdversion(rs.getInt("idversion"));
                version.setIdmarca(rs.getInt("idmarca"));
                version.setNombre_marca(rs.getString("nombre_marca"));
                version.setIdmodelo(rs.getInt("idmodelo"));
                version.setNombre_modelo(rs.getString("nombre_modelo"));
                version.setNombre_version(rs.getString("nombre_version"));
                        
                list_Versiones.add(version);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        
    
        return list_Versiones;
    }    
    
    // Listar versiones por modelo
    public List<Version> listarVersionesPorModelo(int idModelo) {
        List<Version> versiones = new ArrayList<>();
        String query = "SELECT * FROM version WHERE idmodelo = ? ORDER BY nombre_version ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setInt(1, idModelo);
            rs = pst.executeQuery();
            while (rs.next()) {
                Version version = new Version();
                version.setIdversion(rs.getInt("idversion"));
                version.setIdmodelo(rs.getInt("idmodelo"));
                version.setNombre_version(rs.getString("nombre_version"));
                versiones.add(version);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al listar versiones por modelo: " + e);
        }
        
        return versiones;
    }
    
    public List<Version> listarVersionesPorMarcaYModelo(int idMarca, int idModelo) {
    List<Version> listaVersiones = new ArrayList<>();
    String query = "SELECT ve.idversion, ve.nombre_version " +
                   "FROM version AS ve " +
                   "WHERE ve.idmarca = ? AND ve.idmodelo = ? " +
                   "ORDER BY ve.nombre_version ASC";
    try {
        con = cn.conectar();
        pst = con.prepareStatement(query);
        pst.setInt(1, idMarca);   // Seteamos el ID de la marca
        pst.setInt(2, idModelo);  // Seteamos el ID del modelo
        rs = pst.executeQuery();
        
        while (rs.next()) {
            Version version = new Version();
            version.setIdversion(rs.getInt("idversion"));
            version.setNombre_version(rs.getString("nombre_version"));
            listaVersiones.add(version);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al obtener las versiones por marca y modelo: " + e);
    }finally {
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + e);
        }
    }
    return listaVersiones;
}
    
    
    //Buscar id de auto
    public int buscarIdversion(String nombre){
        int id = 0;
        String query = "SELECT idversion FROM version WHERE nombre_version = '" + nombre + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idversion");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de Version" + e);
        }
        return id;
    }

    public void combomv(Panta_version panta){
        
        panta.cmb_marca_version.removeAllItems();
        
        String query = "SELECT * FROM marca ORDER BY nombre_marca ASC";
        
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                
                panta.cmb_marca_version.addItem(rs.getString("nombre_marca"));
              
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return;
    
        
    }
    
    
    public void combomov(Panta_version panta){
        
        panta.cmb_modelo_version.removeAllItems();
        
        String query = "SELECT * FROM modelo ORDER BY nombre_modelo ASC";
        
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                
                panta.cmb_modelo_version.addItem(rs.getString("nombre_modelo"));
              
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return;
    
        
    }
    
    public void combova(){
        
        
        String query = "SELECT * FROM version ORDER BY nombre_version ASC";
        
        Panta_auto pantaut = new Panta_auto();
                
                        
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                
                pantaut.cmb_version.addItem(rs.getString("nombre_version"));
                
                
               
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return;
    
        
    }
    
    
    
}