package model;

public class Consulta {
    
    private int idmarca;
    private int idmodelo;
    private int idversion;
    
    private String nombre_marca;
    private String nombre_modelo;
    private String nombre_version;

    public Consulta() {
    }

    public Consulta(int idmarca, int idmodelo, int idversion, String nombre_marca, String nombre_modelo, String nombre_version) {
        this.idmarca = idmarca;
        this.idmodelo = idmodelo;
        this.idversion = idversion;
        this.nombre_marca = nombre_marca;
        this.nombre_modelo = nombre_modelo;
        this.nombre_version = nombre_version;
    }

    public int getIdmarca() {
        return idmarca;
    }

    public void setIdmarca(int idmarca) {
        this.idmarca = idmarca;
    }

    public int getIdmodelo() {
        return idmodelo;
    }

    public void setIdmodelo(int idmodelo) {
        this.idmodelo = idmodelo;
    }

    public int getIdversion() {
        return idversion;
    }

    public void setIdversion(int idversion) {
        this.idversion = idversion;
    }

    public String getNombre_marca() {
        return nombre_marca;
    }

    public void setNombre_marca(String nombre_marca) {
        this.nombre_marca = nombre_marca;
    }

    public String getNombre_modelo() {
        return nombre_modelo;
    }

    public void setNombre_modelo(String nombre_modelo) {
        this.nombre_modelo = nombre_modelo;
    }

    public String getNombre_version() {
        return nombre_version;
    }

    public void setNombre_version(String nombre_version) {
        this.nombre_version = nombre_version;
    }

    @Override
    public String toString() {
        return "Consulta{" + "idmarca=" + idmarca + ", idmodelo=" + idmodelo + ", idversion=" + idversion + ", nombre_marca=" + nombre_marca + ", nombre_modelo=" + nombre_modelo + ", nombre_version=" + nombre_version + '}';
    }
    
    
    
}
    