package main;

import view.Panta_principal;


public class Principal {

    
    public static void main(String[] args) {
        Panta_principal panta = new Panta_principal();
        panta.setVisible(true);
        panta.setLocationRelativeTo(null);
    }
    
}
