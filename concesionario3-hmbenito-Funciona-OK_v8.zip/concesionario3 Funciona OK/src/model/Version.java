package model;

/**
 *
 * @author cfp40
 */
public class Version {
    
    private int idversion;
    private String nombre_marca;
    private String nombre_modelo;
    private String nombre_version;
    private int idmarca;
    private int idmodelo;

    public Version() {
    }

    public Version(int idversion, String nombre_version, int idmarca, int idmodelo,
                    String nombre_marca, String nombre_modelo) {
        this.idversion = idversion;
        this.nombre_version = nombre_version;
        this.idmarca = idmarca;
        this.idmodelo = idmodelo;
        this.nombre_marca = nombre_marca;
        this.nombre_modelo = nombre_modelo;
    }

    public int getIdversion() {
        return idversion;
    }

    public void setIdversion(int idversion) {
        this.idversion = idversion;
    }

    public String getNombre_version() {
        return nombre_version;
    }

    public void setNombre_version(String nombre_version) {
        this.nombre_version = nombre_version;
    }

    public int getIdmarca() {
        return idmarca;
    }

    public void setIdmarca(int idmarca) {
        this.idmarca = idmarca;
    }

    public int getIdmodelo() {
        return idmodelo;
    }

    public void setIdmodelo(int idmodelo) {
        this.idmodelo = idmodelo;
    }

    public String getNombre_marca() {
        return nombre_marca;
    }

    public void setNombre_marca(String nombre_marca) {
        this.nombre_marca = nombre_marca;
    }

    public String getNombre_modelo() {
        return nombre_modelo;
    }

    public void setNombre_modelo(String nombre_modelo) {
        this.nombre_modelo = nombre_modelo;
    }
    
    
    }