package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


/**
 *
 * @author hmb
 */
public class ConsultaDao {


       //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;


    public ConsultaDao() { 
        System.out.println("pase por ConsultaDao linea 29");
}
    
    //Listar auto
/*    public List listarAuto(){
        
        System.out.println("en AutoDao query LISTAR linea 111");
        List<Auto> list_autos = new ArrayList();
        String query = "SELECT au.idauto, ma.nombre_marca, mo.nombre_modelo, ver.nombre_version,au.anio,"
                + " au.precio, au.kilometros, au.combustible, au.puertas, au.condicion"
                + " FROM auto as au INNER JOIN marca as ma ON au.idmarca = ma.idmarca"
                + " INNER JOIN modelo as mo ON au.idmodelo = mo.idmodelo"
                + " INNER JOIN version as ver ON au.idversion = ver.idversion "
                + " ORDER BY ma.nombre_marca ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Auto auto = new Auto();
                auto.setIdauto(rs.getInt("idauto"));
                auto.setNombre_marca(rs.getString("nombre_marca"));
                auto.setNombre_modelo(rs.getString("nombre_modelo"));
                auto.setNombre_version(rs.getString("nombre_version"));
                auto.setAnio(rs.getInt("anio"));
                auto.setPrecio(rs.getFloat("precio"));
                auto.setKilometros(rs.getInt("kilometros"));
                auto.setCombustible(rs.getString("combustible"));
                auto.setPuertas(rs.getInt("puertas"));
                auto.setCondicion(rs.getString("condicion"));
                
                list_autos.add(auto);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_autos;
    }    */
   
   
    
    public List listar_consulta() {
    System.out.println ("pase por consultaControlador linea 26 query SELECT listarNombre_marca");
    List<Auto> list_consulta = new ArrayList();
                

    String query = "SELECT au.idauto, ma.nombre_marca, mo.nombre_modelo, ver.nombre_version"
                + " FROM auto as au INNER JOIN marca as ma ON au.idmarca = ma.idmarca "
                + " INNER JOIN modelo as mo ON au.idmodelo = mo.idmodelo "
                + " INNER JOIN version as ver ON au.idversion = ver.idversion "
                + " ORDER BY ma.nombre_marca ASC ";
                   
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         rs = pst.executeQuery();

         
                while(rs.next()) {
                        Auto auto = new Auto();
                        auto.setIdauto(rs.getInt("idauto"));  
                        auto.setNombre_marca(rs.getString("nombre_marca"));
                        auto.setNombre_modelo(rs.getString("nombre_modelo"));
                        auto.setNombre_version(rs.getString("nombre_version"));
                    list_consulta.add(auto);
                }        
         } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());}
         return list_consulta;
    }

     public List listar_consultaxMarca(String marcaSelected) {
    System.out.println ("pase por consultaControlador linea 99 query SELECT listarCosnsulta_x_marca");
    List<Auto> list_consultaxMarca = new ArrayList();
                

    String query = "SELECT au.idauto, ma.nombre_marca, mo.nombre_modelo, ver.nombre_version"
                + " FROM auto as au INNER JOIN marca as ma ON au.idmarca = ma.idmarca "
                + " INNER JOIN modelo as mo ON au.idmodelo = mo.idmodelo "
                + " INNER JOIN version as ver ON au.idversion = ver.idversion "
                + " WHERE ma.nombre_marca = ' "+marcaSelected+ " ' "
                + " ORDER BY ma.nombre_marca ASC ";
                   
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         rs = pst.executeQuery();

         
                while(rs.next()) {
                        Auto auto = new Auto();
                        auto.setIdauto(rs.getInt("idauto"));  
                        auto.setNombre_marca(rs.getString("nombre_marca"));
                        auto.setNombre_modelo(rs.getString("nombre_modelo"));
                        auto.setNombre_version(rs.getString("nombre_version"));
                    list_consultaxMarca.add(auto);
                }        
         } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());}
         return list_consultaxMarca;
    }
    
     public List listar_consultaTxtMarca(String marcaSelected) {
    System.out.println ("pase por consultaControlador linea 99 query SELECT listarCosnsulta_x_marca");
    List<Auto> list_consultaxMarca = new ArrayList();
                

    String query = " SELECT au.idauto, ma.nombre_marca, mo.nombre_modelo, ver.nombre_version "
                +" FROM auto as au INNER JOIN marca as ma ON au.idmarca = ma.idmarca "
                +" INNER JOIN modelo as mo ON au.idmodelo = mo.idmodelo "
                +" INNER JOIN version as ver ON au.idversion = ver.idversion WHERE ma.nombre_marca LIKE '%"+marcaSelected+ "%' "
                +" ORDER BY ma.nombre_marca ASC ";
     
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         rs = pst.executeQuery();

         
                while(rs.next()) {
                        Auto auto = new Auto();
                        auto.setIdauto(rs.getInt("idauto"));  
                        auto.setNombre_marca(rs.getString("nombre_marca"));
                        auto.setNombre_modelo(rs.getString("nombre_modelo"));
                        auto.setNombre_version(rs.getString("nombre_version"));
                    list_consultaxMarca.add(auto);
                }        
         } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());}
         return list_consultaxMarca;
    }     
     
      public List listar_consultaTxtModelo(String modeloSelected) {
    System.out.println ("pase por consultaControlador linea 99 query SELECT listarCosnsulta_x_marca");
    List<Auto> list_consultaxModelo = new ArrayList();
                

    String query = " SELECT au.idauto, ma.nombre_marca, mo.nombre_modelo, ver.nombre_version "
                +" FROM auto as au INNER JOIN marca as ma ON au.idmarca = ma.idmarca "
                +" INNER JOIN modelo as mo ON au.idmodelo = mo.idmodelo "
                +" INNER JOIN version as ver ON au.idversion = ver.idversion WHERE mo.nombre_modelo LIKE '%"+modeloSelected+ "%' "
                +" ORDER BY ma.nombre_marca ASC ";
     
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         rs = pst.executeQuery();

         
                while(rs.next()) {
                        Auto auto = new Auto();
                        auto.setIdauto(rs.getInt("idauto"));  
                        auto.setNombre_marca(rs.getString("nombre_marca"));
                        auto.setNombre_modelo(rs.getString("nombre_modelo"));
                        auto.setNombre_version(rs.getString("nombre_version"));
                    list_consultaxModelo.add(auto);
                }        
         } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());}
         return list_consultaxModelo;
    }     
     
         public List listar_consultaTxtVersion(String versionSelected) {
    System.out.println ("pase por consultaControlador linea 99 query SELECT listarCosnsulta_x_marca");
    List<Auto> list_consultaxVersion = new ArrayList();
                

    String query = " SELECT au.idauto, ma.nombre_marca, mo.nombre_modelo, ver.nombre_version "
                +" FROM auto as au INNER JOIN marca as ma ON au.idmarca = ma.idmarca "
                +" INNER JOIN modelo as mo ON au.idmodelo = mo.idmodelo "
                +" INNER JOIN version as ver ON au.idversion = ver.idversion WHERE ver.nombre_version LIKE '%"+versionSelected+ "%' "
                +" ORDER BY ma.nombre_marca ASC ";
     
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         rs = pst.executeQuery();

         
                while(rs.next()) {
                        Auto auto = new Auto();
                        auto.setIdauto(rs.getInt("idauto"));  
                        auto.setNombre_marca(rs.getString("nombre_marca"));
                        auto.setNombre_modelo(rs.getString("nombre_modelo"));
                        auto.setNombre_version(rs.getString("nombre_version"));
                    list_consultaxVersion.add(auto);
                }        
         } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());}
         return list_consultaxVersion;
    }     
     
     
     
     
     
      public List listarAutoFiltrar(String marcabuscar){
        List<Auto> list_autos = new ArrayList();
        String query = "SELECT ma.nombre_marca, mo.nombre_modelo, ver.nombre_version, au.anio,"
                + " au.precio, au.kilometros, au.combustible, au.puertas,au.condicion"
                + " FROM auto AS au INNER JOIN marca AS ma ON au.idmarca = ma.idmarca"
                + " INNER JOIN modelo AS mo ON au.idmodelo = mo.idmodelo"
                + " INNER JOIN version AS ver ON au.idversion = ver.idversion "
                + "WHERE au.marca LIKE '% "+ marcabuscar + "%'"
                + "ORDER BY nombre_marca ASC";     
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Auto auto = new Auto();
                //auto.setIdauto(rs.getInt("idauto")); // no utilizamos idauto en la tabla
                auto.setIdauto(rs.getInt("idauto"));
                auto.setNombre_marca(rs.getString("nombre_marca"));
                auto.setNombre_modelo(rs.getString("nombre_modelo"));
                auto.setNombre_version(rs.getString("nombre_version"));
                list_autos.add(auto);
                          
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_autos;
    } 
   
     
     public List listarModeloxMarca(int SelectedIdmarca){
        List<Auto> list_modelos = new ArrayList();
        String query = "SELECT mo.nombre_modelo FROM marca AS ma INNER JOIN modelo AS mo"
                        + " ON (ma.idmarca = "+ SelectedIdmarca +" AND  mo.idmarca = " + SelectedIdmarca + ")" 
                        + "ORDER BY nombre_marca ASC";     
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Auto auto = new Auto();
                //auto.setIdauto(rs.getInt("idauto")); // no utilizamos idauto en la tabla
                auto.setNombre_modelo(rs.getString("nombre_modelo"));
                
                list_modelos.add(auto);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_modelos;
    }
    
}
    
    
    

