package controlador;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;
import model.Auto;
import model.AutoDao;
import model.Marca;
import model.MarcaDao;
import model.Modelo;
import model.ModeloDao;
import model.Version;
import model.VersionDao;
import model.ConsultaDao;
import view.Panta_auto;
import view.Panta_consulta;
import view.Panta_marca;
import view.Panta_modelo;
import view.Panta_principal;
import view.Panta_version;


/**
 *
 * @author hmb
 */
   
public class ConsultaControlador implements ActionListener, MouseListener, KeyListener {

    private Marca marca;
    private MarcaDao marcaDao;
    private Modelo modelo;
    private ModeloDao modeloDao;
    private Version version;
    private VersionDao versionDao;
    private Auto auto;
    private AutoDao autoDao;
    private ConsultaDao consultaDao;
    private Panta_consulta panta;
    private Panta_principal pantaprincipal;
    private int selector;
    private ModeloControlador modeloControlador;
    private VersionControlador versionControlador; 
    private int idautoAux1;
    private int idauto;
    private String marcaSelected;
    private String modeloSelected;
    private String versionSelected;
    
    DefaultTableModel model = new DefaultTableModel();
 

    
    public ConsultaControlador(Panta_consulta panta, Marca marca, MarcaDao marcaDao,
            Modelo  modelo, ModeloDao modeloDao, Version version, VersionDao versionDao,
            Auto auto, AutoDao autoDao, ConsultaDao consultaDao, ModeloControlador modeloControlador,VersionControlador versionControlador){
        

        
        System.out.println("pase por consultaControlador linea 77");
        
        this.panta = panta;
        this.marca = marca;
        this.marcaDao = marcaDao;
        this.modelo = modelo;
        this.modeloDao = modeloDao;
        this.version = version;
        this.versionDao = versionDao;
        this.auto = auto;
        this.autoDao = autoDao;
        this.consultaDao = consultaDao;
        this.modeloControlador = modeloControlador;
        this.versionControlador = versionControlador;
        
        
        
        //Listado de auto
        this.panta.tb_consulta.addMouseListener(this);
        
          
        //Combo box marca/modelo/version en selected
        this.panta.cmb_marca_consulta.addActionListener(this);
        this.panta.cmb_modelo_consulta.addActionListener(this);
        this.panta.cmb_version_consulta.addActionListener(this);
        
        this.panta.txt_marca_consulta.addActionListener(this);
        this.panta.txt_modelo_consulta.addActionListener(this);
        this.panta.txt_version_consulta.addActionListener(this);
        
 
        this.panta.cmb_marca_consulta.addMouseListener(this);
        this.panta.cmb_modelo_consulta.addMouseListener(this);
        this.panta.cmb_version_consulta.addMouseListener(this);
        
        this.panta.tb_consulta.addMouseListener(this);
        this.panta.txt_marca_consulta.addKeyListener(this);
        this.panta.txt_modelo_consulta.addKeyListener(this);
        this.panta.txt_version_consulta.addKeyListener(this);
        this.panta.btn_limpiar_consulta.addActionListener(this);
        
        //Listado de modelo
           
        listarConsulta();
        listarConsulta_marca();
        listarConsulta_modelo();
        listarConsulta_version();
        System.out.println ("pase por consultaontroller linea 113 despues de listarConsulta" );
       
        }


    @Override
    public void actionPerformed(ActionEvent e) { 
                listarConsulta();
             
            if(e.getSource().equals(panta.btn_limpiar_consulta)) {
                    limpiarCampos();
                    listarConsulta();}
        
            if(e.getSource().equals(panta.cmb_marca_consulta)) { //listarModelos();
               
                  
                  System.out.println("Consultacontroller linea 326 - cambie de marca en el BOX ");}   
            if(e.getSource().equals(panta.cmb_modelo_consulta)) { //listarVersiones();
               
                    
                     
            if(e.getSource().equals(panta.cmb_version_consulta)) { //listarVersiones();
                    
            }

  System.out.println("Consultacontroller linea 158 - cambie de modelo en el BOX ");}
      
     
    }
    
            
    @Override
    public void mouseClicked(MouseEvent e) {
             if(e.getSource() == panta.tb_consulta){
            int row = panta.tb_consulta.rowAtPoint(e.getPoint()); 
            panta.txt_marca_consulta.setText(panta.tb_consulta.getValueAt(row,1).toString());
            panta.txt_modelo_consulta.setText(panta.tb_consulta.getValueAt(row,2).toString());
            panta.txt_version_consulta.setText(panta.tb_consulta.getValueAt(row,3).toString());
            idautoAux1 = Integer.parseInt(panta.tb_consulta.getValueAt(row,0).toString());
            System.out.println("Consultacontroller linea 215 - ");  
        
            panta.cmb_marca_consulta.setSelectedItem(panta.tb_consulta.getValueAt(row,1).toString());
            panta.cmb_modelo_consulta.setSelectedItem(panta.tb_consulta.getValueAt(row,2).toString());
            panta.cmb_version_consulta.setSelectedItem(panta.tb_consulta.getValueAt(row,3).toString());  
            
           
            if(e.getSource() == panta.cmb_marca_consulta){
            marcaSelected = panta.cmb_marca_consulta.getSelectedItem().toString();
            System.out.println("Consultacontroller linea 226 marcaSelected = " + marcaSelected);
            
                 listarConsultaxCombomarca();
             }
             
          
            if(e.getSource() == panta.cmb_modelo_consulta){
                        
            }
            if(e.getSource() == panta.cmb_version_consulta){
                 
           
            }
                
            
    }
}                   
    
    @Override
    public void mousePressed(MouseEvent e) {
         
        
    }

    @Override
    public void mouseReleased(MouseEvent e){     
         if(e.getSource() == panta.tb_consulta){
            int row = panta.tb_consulta.rowAtPoint(e.getPoint()); 
            panta.txt_marca_consulta.setText(panta.tb_consulta.getValueAt(row,1).toString());
            panta.txt_modelo_consulta.setText(panta.tb_consulta.getValueAt(row,2).toString());
            panta.txt_version_consulta.setText(panta.tb_consulta.getValueAt(row,3).toString());
            idautoAux1 = Integer.parseInt(panta.tb_consulta.getValueAt(row,0).toString());
            System.out.println("Consultacontroller linea 407 - ");  
        
            panta.cmb_marca_consulta.setSelectedItem(panta.tb_consulta.getValueAt(row,1).toString());
            panta.cmb_modelo_consulta.setSelectedItem(panta.tb_consulta.getValueAt(row,2).toString());
            panta.cmb_version_consulta.setSelectedItem(panta.tb_consulta.getValueAt(row,3).toString());  
            
             
            }
}
    

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}

    @Override
    public void keyTyped(KeyEvent e) { }

    @Override
    public void keyPressed(KeyEvent e) {
            if(e.getSource().equals( panta.txt_marca_consulta)) {
                listarConsultaTXTmarca();}
            if(e.getSource().equals( panta.txt_modelo_consulta)) {
                listarConsultaTXTmodelo();}
            if(e.getSource().equals( panta.txt_version_consulta)) {
                listarConsultaTXTversion();}       
    }

    @Override
    public void keyReleased(KeyEvent e) {
            if(e.getSource().equals( panta.txt_marca_consulta)) {
                listarConsultaTXTmarca();}
            if(e.getSource().equals( panta.txt_modelo_consulta)) {
                listarConsultaTXTmodelo();}
            if(e.getSource().equals( panta.txt_version_consulta)) {
                 listarConsultaTXTversion();}
    }

       
    public void limpiarTabla (){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_marca_consulta.setText("");
        panta.txt_modelo_consulta.setText("");
        panta.txt_version_consulta.setText("");
    }
    
    // parte nueva
   
 public void listarConsulta(){
       
    System.out.println("pase por consultaControlador - listarAuto - linea 362");
        
           
        List<Auto> list = consultaDao.listar_consulta();
               model = (DefaultTableModel) panta.tb_consulta.getModel();
        Object[] row = new Object[4];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
          
            row[0] = list.get(i).getIdauto();
            row[1] = list.get(i).getNombre_marca();
            row[2] = list.get(i).getNombre_modelo();
            row[3] = list.get(i).getNombre_version();
            
            model.addRow(row);
          
        }   
    }



 public void listarConsulta_marca(){
       
    System.out.println("pase por consultaControlador - listarAuto - linea 362");
        
         List<Auto> list = consultaDao.listar_consulta();
        List<String> list_marca = new ArrayList<>();
               
        for(int i = 0; i < list.size(); i++){
            
            list_marca.add(list.get(i).getNombre_marca());
        }
        List<String> list_marca_sinDuplicados = list_marca.stream().distinct().toList();

        for(int i = 0; i < list_marca_sinDuplicados.size(); i++){
            panta.cmb_marca_consulta.addItem(list_marca_sinDuplicados.get(i));
          }   
    }
 
 public void listarConsulta_modelo(){
       
    System.out.println("pase por consultaControlador - listarAuto - linea 320");
        
           
        List<Auto> list = consultaDao.listar_consulta();
        List<String> list_modelo = new ArrayList<>();
               
        for(int i = 0; i < list.size(); i++){
            
            list_modelo.add(list.get(i).getNombre_modelo());
        }
        List<String> list_modelo_sinDuplicados = list_modelo.stream().distinct().toList();

        for(int i = 0; i < list_modelo_sinDuplicados.size(); i++){
            panta.cmb_modelo_consulta.addItem(list_modelo_sinDuplicados.get(i));
          }   
    }

public void listarConsulta_version(){
       
    System.out.println("pase por consultaControlador - listarAuto - linea 320");
        
           
        List<Auto> list = consultaDao.listar_consulta();
        List<String> list_version = new ArrayList<>();
               
        for(int i = 0; i < list.size(); i++){
            
            list_version.add(list.get(i).getNombre_version());
        }
        List<String> list_version_sinDuplicados = list_version.stream().distinct().toList();

        for(int i = 0; i < list_version_sinDuplicados.size(); i++){
            panta.cmb_version_consulta.addItem(list_version_sinDuplicados.get(i));
          }   
    }

public void listarConsultaxCombomarca(){
       
    System.out.println("pase por consultaControlador - listarAuto - linea 362");
        
       List<Auto> list = consultaDao.listar_consultaxMarca(marcaSelected);
       Object[] row = new Object[4];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
          
            row[0] = list.get(i).getIdauto();
            row[1] = list.get(i).getNombre_marca();
            row[2] = list.get(i).getNombre_modelo();
            row[3] = list.get(i).getNombre_version();
            
            model.addRow(row);
           }   
    }




public void listarConsultaTXTmarca(){
       
    System.out.println("pase por consultaControlador - listarAuto - linea 362");
        marcaSelected = panta.txt_marca_consulta.getText();
       List<Auto> list = consultaDao.listar_consultaTxtMarca(marcaSelected);
       Object[] row = new Object[4];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
          
            row[0] = list.get(i).getIdauto();
            row[1] = list.get(i).getNombre_marca();
            row[2] = list.get(i).getNombre_modelo();
            row[3] = list.get(i).getNombre_version();
            
            model.addRow(row);
           }   
    }


public void listarConsultaTXTmodelo(){
       
    System.out.println("pase por consultaControlador - listarAuto - linea 362");
        modeloSelected = panta.txt_modelo_consulta.getText();
       List<Auto> list = consultaDao.listar_consultaTxtModelo(modeloSelected);
       Object[] row = new Object[4];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
          
            row[0] = list.get(i).getIdauto();
            row[1] = list.get(i).getNombre_marca();
            row[2] = list.get(i).getNombre_modelo();
            row[3] = list.get(i).getNombre_version();
            
            model.addRow(row);
           }   
    }

public void listarConsultaTXTversion(){
       
    System.out.println("pase por consultaControlador - listarAuto - linea 362");
        versionSelected = panta.txt_version_consulta.getText();
       List<Auto> list = consultaDao.listar_consultaTxtVersion(versionSelected);
       Object[] row = new Object[4];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
          
            row[0] = list.get(i).getIdauto();
            row[1] = list.get(i).getNombre_marca();
            row[2] = list.get(i).getNombre_modelo();
            row[3] = list.get(i).getNombre_version();
            
            model.addRow(row);
           }   
    }
    
}
