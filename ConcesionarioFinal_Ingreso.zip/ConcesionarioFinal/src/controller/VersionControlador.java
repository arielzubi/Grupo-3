package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Version;
import model.VersionDao;
import model.MarcaDao;
import model.ModeloDao;
import view.Panta_version;

public class VersionControlador implements ActionListener, MouseListener, KeyListener {
    private Version version;
    private VersionDao versionDao;
    private MarcaDao marcaDao;
    private ModeloDao modeloDao;
    private Panta_version panta;

    DefaultTableModel model = new DefaultTableModel();

    public VersionControlador(Version version, VersionDao versionDao, Panta_version panta) {
        this.version = version;
        this.versionDao = versionDao;
        this.panta = panta;
        this.marcaDao = new MarcaDao();
        this.modeloDao = new ModeloDao();

        // Botones de la pantalla
        this.panta.btn_agregar_version.addActionListener(this);
        this.panta.btn_modificar_version.addActionListener(this);
        this.panta.btn_borrar_version.addActionListener(this);
        this.panta.btn_limpiar_version.addActionListener(this);

        // Listeners de la tabla y combos
        this.panta.tb_version.addMouseListener(this);
        this.panta.cmb_marca_version.addActionListener(this);

              
        cargarMarcas();
        listarVersiones(); 
        versionDao.combomv(panta);
        versionDao.combomov(panta);
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == panta.btn_agregar_version) {
            if (panta.txt_version.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "El campo Versión es obligatorio");
            } else {
                int idMode = modeloDao.buscarIdmodelo(panta.cmb_modelo_version.getSelectedItem().toString());
                int idMar = marcaDao.buscarIdmarca(panta.cmb_marca_version.getSelectedItem().toString());
                version.setNombre_version(panta.txt_version.getText());
                version.setIdmodelo(idMode);
                version.setIdmarca(idMar);

                if (versionDao.agregarVersion(version)) {
                    limpiarTabla();
                    limpiarCampos();
                    listarVersiones();
                    JOptionPane.showMessageDialog(null, "Se agregó la Versión");
                } else {
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar la Versión" + e.toString());
                }
            }
        } else if (e.getSource() == panta.btn_modificar_version) {
            if (panta.txt_version.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            } else {
                
                version.setIdversion(Integer.parseInt(panta.txt_idversion.getText()));
                
                version.setNombre_version(panta.txt_version.getText());
                              
                int idMod = modeloDao.buscarIdmodelo(panta.cmb_modelo_version.getSelectedItem().toString());
                version.setIdmodelo(idMod);
                int idMar = marcaDao.buscarIdmarca(panta.cmb_marca_version.getSelectedItem().toString());
                version.setIdmarca(idMar);
                
                
                if (versionDao.modificarVersion(version)) {
                    limpiarTabla();
                    limpiarCampos();
                    listarVersiones();
                    JOptionPane.showMessageDialog(null, "Se modificó la Versión");
                } else {
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar la Versión" + e.toString());
                }
            }
        } else if (e.getSource() == panta.btn_borrar_version) {
            if (panta.txt_version.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            } else {
                int id = Integer.parseInt(panta.txt_idversion.getText());
                if (versionDao.borrarVersion(id)) {
                    limpiarTabla();
                    limpiarCampos();
                    listarVersiones();
                    JOptionPane.showMessageDialog(null, "Se eliminó la Versión");
                } else {
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar la Versión" + e.toString());
                }
            }
        } else if (e.getSource() == panta.btn_limpiar_version) {
            limpiarTabla();
            limpiarCampos();
            listarVersiones();
            panta.btn_agregar_version.setEnabled(true);
        } else if (e.getSource() == panta.cmb_marca_version) {
            String marcaSeleccionada = (String) panta.cmb_marca_version.getSelectedItem();
            cargarModelosPorMarca(marcaSeleccionada);
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if (e.getSource() == panta.tb_version) {
            int row = panta.tb_version.rowAtPoint(e.getPoint());
            panta.cmb_marca_version.setSelectedItem(panta.tb_version.getValueAt(row, 0).toString());
            panta.cmb_modelo_version.setSelectedItem(panta.tb_version.getValueAt(row, 1).toString());
            panta.txt_version.setText(panta.tb_version.getValueAt(row, 2).toString());
            panta.txt_idversion.setText(panta.tb_version.getValueAt(row, 3).toString());
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getSource().equals(panta.txt_version)) {
            limpiarTabla();
            listarVersiones();
        }
    }

    public void listarVersiones() {
        List<Version> list = versionDao.listarVersion();
        model = (DefaultTableModel) panta.tb_version.getModel();
        Object[] row = new Object[4];
        limpiarTabla();
        for (int i = 0; i < list.size(); i++) {
            row[0] = list.get(i).getNombre_marca();
            row[1] = list.get(i).getNombre_modelo();
            row[2] = list.get(i).getNombre_version();
            row[3] = list.get(i).getIdversion();
            model.addRow(row);
        }
    }

    private void cargarMarcas() {
        List<String> marcas = marcaDao.obtenerMarcas();
        if (!marcas.isEmpty()) {
            DefaultComboBoxModel<String> modeloCombo = new DefaultComboBoxModel<>();
            for (String marca : marcas) {
                modeloCombo.addElement(marca);
            }
            panta.cmb_marca_version.setModel(modeloCombo);

            // Cargar los modelos de la primera marca por defecto
            String primeraMarca = marcas.get(0);
            cargarModelosPorMarca(primeraMarca);
        } else {
            JOptionPane.showMessageDialog(panta, "No se encontraron marcas.");
        }
    }

    private void cargarModelosPorMarca(String marca) {
        List<String> modelos = modeloDao.obtenerModelosPorMarca(marca);
        if (!modelos.isEmpty()) {
            DefaultComboBoxModel<String> modeloCombo = new DefaultComboBoxModel<>();
            for (String modelo : modelos) {
                modeloCombo.addElement(modelo);
            }
            panta.cmb_modelo_version.setModel(modeloCombo);
        } //else {
           // JOptionPane.showMessageDialog(panta, "No se encontraron modelos para la marca seleccionada.");
        //}
    }

    public void limpiarTabla() {
        while (model.getRowCount() > 0) {
            model.removeRow(0);
        }
    }

    public void limpiarCampos() {
        panta.txt_version.setText("");
        panta.txt_idversion.setText("");
    }

    @Override
    public void mouseClicked(MouseEvent e) {}
    @Override
    public void mousePressed(MouseEvent e) {}
    @Override
    public void mouseEntered(MouseEvent e) {}
    @Override
    public void mouseExited(MouseEvent e) {}
    @Override
    public void keyTyped(KeyEvent e) {}
    @Override
    public void keyPressed(KeyEvent e) {}
}
