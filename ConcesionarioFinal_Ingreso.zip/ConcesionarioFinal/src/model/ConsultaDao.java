package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ConsultaDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public ConsultaDao() {
    }
    //Agregar consulta
    
    

    //Listar consulta
    public List listarConsulta(){
        List<Consulta> list_consultas = new ArrayList();
        String query = "SELECT ma.nombre_marca, mo.nombre_modelo, ve.nombre_version FROM auto as au inner join marca as ma on au.idmarca = ma.idmarca inner join modelo as mo on au.idmodelo = mo.idmodelo inner join version as ve on au.idversion = ve.idversion ORDER BY nombre_version ASC  ";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Consulta consulta = new Consulta();
                
                consulta.setNombre_marca(rs.getString("nombre_marca"));
                consulta.setNombre_modelo(rs.getString("nombre_modelo"));
                consulta.setNombre_version(rs.getString("nombre_version"));
                list_consultas.add(consulta);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_consultas;
    }
        
         public List listarConsultaVer(String marca){
        List<Consulta> list_consultas = new ArrayList();
        
        String query = "SELECT ma.nombre_marca, mo.nombre_modelo,ve.nombre_version FROM auto as au inner join Marca as ma on au.idmarca = ma.idmarca inner join modelo as mo on au.idmodelo = mo.idmodelo inner join version as ve on au.idversion = ve.idversion where nombre_marca LIKE '%" + marca + "%' ";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Consulta consulta = new Consulta();
                
                
                consulta.setNombre_marca(rs.getString("nombre_marca"));
                consulta.setNombre_modelo(rs.getString("nombre_modelo"));
                consulta.setNombre_version(rs.getString("nombre_version"));
                list_consultas.add(consulta);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_consultas;
        
         }
  
    
 
}
