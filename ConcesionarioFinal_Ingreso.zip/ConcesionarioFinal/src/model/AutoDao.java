package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import view.Panta_auto;


public class AutoDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public AutoDao() {
    }
    //Agregar auto
    public boolean agregarAuto(Auto auto){
        String query = "INSERT INTO auto (idmarca, idmodelo, idversion, anio, precio, kilometros, combustible, puertas, condicion) VALUES(?,?,?,?,?,?,?,?,?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setInt(1,auto.getIdmarca());
            pst.setInt(2,auto.getIdmodelo());
            pst.setInt(3,auto.getIdversion());
            pst.setInt(4,auto.getAnio());
            pst.setDouble(5,auto.getPrecio());
            pst.setInt(6,auto.getKilometros());
            pst.setString(7,auto.getCombustible());
            pst.setInt(8,auto.getPuertas());
            pst.setString(9,auto.getCondicion());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar el auto" + e);
            return false;
        }
    }
    
    //Modificar auto
    public boolean modificarAuto(Auto auto){
        
        
        String query = "UPDATE auto SET idmarca = ?, idmodelo = ?, idversion = ?, anio = ?, precio = ?, kilometros = ?, combustible = ?, puertas = ?, condicion = ? WHERE idauto = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setInt(1,auto.getIdmarca());
            pst.setInt(2,auto.getIdmodelo());
            pst.setInt(3,auto.getIdversion());
            pst.setInt(4,auto.getAnio());
            pst.setDouble(5,auto.getPrecio());
            pst.setInt(6,auto.getKilometros());
            pst.setString(7,auto.getCombustible());
            pst.setInt(8,auto.getPuertas());
            pst.setString(9,auto.getCondicion());
            pst.setInt(10,auto.getIdauto());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar el auto" + e.toString());
            return false;
        }
    }

    //Borrar auto
    public boolean borrarAuto(int id){
        String query = "DELETE FROM auto WHERE idauto = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar el auto" + e.toString());
            return false;
        }
    }

    //Listar auto
    public List listarAuto(){
        List<Auto> list_autos = new ArrayList();
        String query = "SELECT au.*, ma.nombre_marca, mo.nombre_modelo, ve.nombre_version FROM auto as au inner join marca as ma on au.idmarca = ma.idmarca inner join modelo as mo on au.idmodelo = mo.idmodelo inner join version as ve on au.idversion = ve.idversion ORDER BY nombre_marca ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Auto auto = new Auto();
                auto.setIdauto(rs.getInt("idauto"));
                auto.setNombre_marca(rs.getString("nombre_marca"));
                auto.setNombre_modelo(rs.getString("nombre_modelo"));
                auto.setNombre_version(rs.getString("nombre_version"));
                auto.setAnio(rs.getInt("anio"));
                auto.setPrecio(rs.getDouble("precio"));
                auto.setKilometros(rs.getInt("kilometros"));
                auto.setCombustible(rs.getString("combustible"));
                auto.setPuertas(rs.getInt("puertas"));
                auto.setCondicion(rs.getString("condicion"));

                list_autos.add(auto);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_autos;
    } 
    
    //Buscar id de auto
    public int buscarIdAuto(String nombre){
        int id = 0;
        String query = "SELECT idauto FROM auto WHERE idauto = '" + nombre + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idauto");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de auto" + e);
        }
        return id;
    }
    
    
    public List<Modelo> listarModelosPorMarca(int idMarca) {
    List<Modelo> modelos = new ArrayList<>();
    String query = "SELECT * FROM modelo WHERE idmarca = ? ORDER BY nombre_modelo ASC";
    try {
        con = cn.conectar();
        pst = con.prepareStatement(query);
        pst.setInt(1, idMarca);
        rs = pst.executeQuery();
        while (rs.next()) {
            Modelo modelo = new Modelo();
            modelo.setIdmodelo(rs.getInt("idmodelo"));
            modelo.setNombre_modelo(rs.getString("nombre_modelo"));
            modelos.add(modelo);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al listar modelos: " + e);
    }finally {
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + e);
        }
    }
    return modelos;
}

    public List<Version> listarVersionesPorModelo(int idModelo) {
    List<Version> versiones = new ArrayList<>();
    String query = "SELECT * FROM version WHERE idmodelo = ? ORDER BY nombre_version ASC";
    try {
        con = cn.conectar();
        pst = con.prepareStatement(query);
        pst.setInt(1, idModelo);
        rs = pst.executeQuery();
        while (rs.next()) {
            Version version = new Version();
            version.setIdversion(rs.getInt("idversion"));
            version.setNombre_version(rs.getString("nombre_version"));
            versiones.add(version);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al listar versiones: " + e);
    }finally {
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar recursos: " + e);
        }
    }
    return versiones;
}


    public void comboma(Panta_auto panta){
        
        panta.cmb_marca.removeAllItems();
        
        String query = "SELECT * FROM marca ORDER BY nombre_marca ASC";
        
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                panta.cmb_marca.addItem(rs.getString("nombre_marca"));
              
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return;
    
        
    }
    
    public void combomoa(Panta_auto panta){
        
        panta.cmb_modelo.removeAllItems();
        
        String query = "SELECT * FROM modelo ORDER BY nombre_modelo ASC";
        
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                panta.cmb_modelo.addItem(rs.getString("nombre_modelo"));
              
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return;
    
        
    }
    
    
    public void combova(Panta_auto panta){
        
        panta.cmb_version.removeAllItems();
        
        String query = "SELECT * FROM version ORDER BY nombre_version ASC";
        
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                panta.cmb_version.addItem(rs.getString("nombre_version"));
              
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return;
    
        
    }
    
}
