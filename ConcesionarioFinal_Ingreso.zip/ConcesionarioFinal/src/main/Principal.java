package main;

import view.Panta_ingreso;



public class Principal {

    
    public static void main(String[] args) {
        Panta_ingreso panta = new Panta_ingreso();
        panta.setVisible(true);
        panta.setLocationRelativeTo(null);
    }
    
}
