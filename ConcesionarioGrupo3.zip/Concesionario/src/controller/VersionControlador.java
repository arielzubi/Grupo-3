package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Version;
import model.VersionDao;
import view.Panta_auto;
import view.Panta_version;

public class VersionControlador implements ActionListener, MouseListener, KeyListener {
    private Version version;
    private VersionDao versionDao;
    private Panta_version panta;

    DefaultTableModel model = new DefaultTableModel();

    public VersionControlador(Version version, VersionDao versionDao, Panta_version panta) {
        this.version = version;
        this.versionDao = versionDao;
        this.panta = panta;
        
        //Botón de registrar auto
        this.panta.btn_agregar_version.addActionListener(this);
        //Botón de modificar auto
        this.panta.btn_modificar_version.addActionListener(this);
        //Botón de borrar auto
        this.panta.btn_borrar_version.addActionListener(this);
        //Botón de limpiar
        this.panta.btn_limpiar_version.addActionListener(this);
        
        //Listado de Version
        this.panta.tb_version.addMouseListener(this);
              
        listarVersiones(); 
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
            if(e.getSource() == panta.btn_agregar_version){
            //verifica si el campo nombre está vacío
            if(panta.txt_version.getText().equals("")){
                JOptionPane.showMessageDialog(null, "El campo Version es obligatorio");
            }else{
                //Realiza el agregado
                version.setNombre_version(panta.txt_version.getText());
                if(versionDao.agregarVersion(version)){
                    limpiarTabla();
                    limpiarCampos();
                    listarVersiones();
                    JOptionPane.showMessageDialog(null, "Se agregó la Version");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar la Version");
                }
            }
        }else if(e.getSource() == panta.btn_modificar_version){
            //verifica si el campo id está vacío
            if(panta.txt_version.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza la modificación
                version.setNombre_version(panta.txt_version.getText());
                
                if(versionDao.modificarVersion(version)){
                    limpiarTabla();
                    limpiarCampos();
                    listarVersiones();
                    JOptionPane.showMessageDialog(null, "Se modificó el auto");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el auto");
                }
            }
        }else if(e.getSource() == panta.btn_borrar_version){
            //verifica si el campo id está vacío
            if(panta.txt_version.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza el borrado
                int id = Integer.parseInt(panta.txt_version.getText());
                if(versionDao.borrarVersion(id)){
                    limpiarTabla();
                    limpiarCampos();
                    listarVersiones();
                    JOptionPane.showMessageDialog(null, "Se eliminó el auto");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar el auto");
                }
            }
        }else if(e.getSource() == panta.btn_limpiar_version){
                limpiarTabla();
                limpiarCampos();
                listarVersiones();    
                panta.btn_agregar_version.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
        if(e.getSource() == panta.tb_version){
            int row = panta.tb_version.rowAtPoint(e.getPoint());
            panta.cmb_marca_version.setSelectedItem(panta.tb_version.getValueAt(row,0).toString());
            panta.cmb_modelo_version.setSelectedItem(panta.tb_version.getValueAt(row,1).toString());
            panta.txt_version.setText(panta.tb_version.getValueAt(row,2).toString());
            panta.txt_idversion.setText(panta.tb_version.getValueAt(row,3).toString());
        }       
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getSource().equals(panta.txt_version))
            limpiarTabla();
            listarVersiones();
    }

    //Listar todos los versiones
    public void listarVersiones(){

        panta.cmb_modelo_version.removeAllItems();
        panta.cmb_marca_version.removeAllItems();

        List<Version> list = versionDao.listarVersion();
        model = (DefaultTableModel) panta.tb_version.getModel();
        Object[] row = new Object[4];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getNombre_marca();
            row[1] = list.get(i).getNombre_modelo();
            row[2] = list.get(i).getNombre_version();
            row[3] = list.get(i).getIdversion();
            
            model.addRow(row);
           
            panta.cmb_modelo_version.addItem(list.get(i).getNombre_modelo());
            panta.cmb_marca_version.addItem(list.get(i).getNombre_marca());
            
            
        }
    }


    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_version.setText("");
        panta.txt_idversion.setText("");
        
        
    }
    
}
