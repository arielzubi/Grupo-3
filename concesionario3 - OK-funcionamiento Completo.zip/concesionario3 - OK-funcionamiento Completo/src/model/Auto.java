package model;

/**
 *
 * @author hmb
 */
public class Auto {
    
    
    
    private int idauto;
    private int idmarca;
    private int idmodelo;
    private int idversion;
    private int anio;
    private float precio;
    private int kilometros;
    private String combustible;
    private boolean combustible2;
    private int puertas;
    private String condicion;
    
    
    private String nombre_modelo;
    private String nombre_version;
    private String nombre_marca;
    // atributos adicionales
    private String marcabuscar;
    

    public Auto() {
    }


    
    public Auto(int idauto, int idmarca, int idmodelo, int idversion, int anio, float precio,
            int kilometros, String combustible, int puertas, String condicion,
            String nombre_marca, String nombre_modelo, String nombre_version) {
        this.idauto = idauto;
        this.idmarca = idmarca;
        this.idmodelo = idmodelo;
        this.idversion = idversion;
        this.anio = anio;
        this.precio = precio;
        this.kilometros = kilometros;
        this.combustible = combustible;
        this.combustible2 = combustible2;
        this.puertas = puertas;
        this.condicion = condicion;
        this.marcabuscar = marcabuscar;
        this.nombre_marca = nombre_marca;
        this.nombre_modelo = nombre_modelo;
        this.nombre_version = nombre_version;
        
         System.out.println ("pase por model auto linea 40");
    }

    public int getIdauto() {
        return idauto;
    }

    public void setIdauto(int idauto) {
        this.idauto = idauto;
    }

    public int getIdmarca() {
        return idmarca;
    }

    public void setIdmarca(int idmarca) {
        this.idmarca = idmarca;
    }

    public int getIdmodelo() {
        return idmodelo;
    }

    public void setIdmodelo(int idmodelo) {
        this.idmodelo = idmodelo;
    }

    public int getIdversion() {
        return idversion;
    }

    public void setIdversion(int idversion) {
        this.idversion = idversion;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public int getKilometros() {
        return kilometros;
    }

    public void setKilometros(int kilometros) {
        this.kilometros = kilometros;
    }

    public String getCombustible() {
        return combustible;
    }

    public void setCombustible(String combustible) {
        this.combustible = combustible;
    }

    public boolean isCombustible2() {
        return combustible2;
    }

    public void setCombustible2(boolean combustible2) {
        this.combustible2 = combustible2;
    }

    public int getPuertas() {
        return puertas;
    }

    public void setPuertas(int puertas) {
        this.puertas = puertas;
    }

    public String getCondicion() {
        return condicion;
    }

    public void setCondicion(String condicion) {
        this.condicion = condicion;
    }

    public String getMarcabuscar() {
        return marcabuscar;
    }

    public void setMarcabuscar(String marcabuscar) {
        this.marcabuscar = marcabuscar;
    }

    public String getNombre_modelo() {
        return nombre_modelo;
    }

    public void setNombre_modelo(String nombre_modelo) {
        this.nombre_modelo = nombre_modelo;
    }

    public String getNombre_version() {
        return nombre_version;
    }

    public void setNombre_version(String nombre_version) {
        this.nombre_version = nombre_version;
    }

    public String getNombre_marca() {
        return nombre_marca;
    }

    public void setNombre_marca(String nombre_marca) {
        this.nombre_marca = nombre_marca;
    }

    public void nada_para_borrar () {
        System.out.println ("pase por model auto linea 40");
    }
     
    
}
