package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;

import javax.swing.table.DefaultTableModel;
import model.Marca;
import model.MarcaDao;
import model.Modelo;
import model.ModeloDao;
import model.Version;
import model.VersionDao;
import model.Auto;
import model.AutoDao;
import view.Panta_marca;
import view.Panta_modelo;
import view.Panta_auto;
import view.Panta_consulta;
import view.Panta_principal;
import view.Panta_version;
import controlador.ModeloControlador;
import controlador.VersionControlador;


/**
 *
 * @author hmb
 */
   
public class AutoControlador implements ActionListener, MouseListener, KeyListener {

    private Marca marca;
    private MarcaDao marcaDao;
    private Modelo modelo;
    private ModeloDao modeloDao;
    private Version version;
    private VersionDao versionDao;
    private Auto auto;
    private AutoDao autoDao;
    private Panta_marca pantamarca;
    private Panta_modelo pantamodelo;
    private Panta_version pantaversion;
    private Panta_auto panta;
    private Panta_consulta pantaconsulta;
    private Panta_principal pantaprincipal;
    private int selector;
    private ModeloControlador modeloControlador;
    private VersionControlador versionControlador; 
    private int idautoAux1;
    private int idauto;
    private String condicion;
    
    DefaultTableModel model = new DefaultTableModel();
 
    
    public AutoControlador(Panta_marca pantamarca,Panta_modelo pantamodelo, Panta_version pantaversion,
            Panta_auto  panta, Panta_consulta pantaconsulta, Marca marca, MarcaDao marcaDao,
            Modelo  modelo, ModeloDao modeloDao, Version version, VersionDao versionDao,
            Auto auto, AutoDao autoDao, ModeloControlador modeloControlador,VersionControlador versionControlador){
        
        
        System.out.println("pase por AutoControlador linea 77");
        
        this.pantamarca = pantamarca;
        this.pantamodelo = pantamodelo;
        this.pantaversion = pantaversion;
        this.panta = panta;
        this.pantaconsulta = pantaconsulta;
        this.marca = marca;
        this.marcaDao = marcaDao;
        this.modelo = modelo;
        this.modeloDao = modeloDao;
        this.version = version;
        this.versionDao = versionDao;
        this.auto = auto;
        this.autoDao = autoDao;
        this.modeloControlador = modeloControlador;
        this.versionControlador = versionControlador;
        
        
        //Botónes  registrar/modificar/borrar/limpiar / volver en auto
        this.panta.btn_agregar_auto.addActionListener(this);
        this.panta.btn_modificar_auto.addActionListener(this);
        this.panta.btn_borrar_auto.addActionListener(this);
        this.panta.btn_limpiar_auto.addActionListener(this);
        this.panta.btn_volver.addActionListener(this);
        this.panta.ckb_condicion.addActionListener(this);
        
        //Listado de auto
        this.panta.tb_auto.addMouseListener(this);
          
        //Combo box marca/modelo/version en selected
        this.panta.cmb_marca.addActionListener(this);
       // this.panta.cmb_modelo.addActionListener(this);   ANULADO, crea conflicto de LISTENER porque estan activos en clase modeloControlador y versionControlador
      //  this.panta.cmb_version.addActionListener(this);  ANULADO, crea conflicto de LISTENER porque estan activos en clase modeloControlador y versionControlador
                // EL CONFLICTO DE LISTENER ES INHABILITA LA SELECCION EN EL COMBO, MUESTRA LOS ELEMENTOS PERO NO PERMITE ELEGIR
                // A TENER EN CUENTA PARA PROXIMOS DESARROLLOS
        this.panta.rb_diesel.addActionListener(this);
        this.panta.rb_gnc.addActionListener(this);
        this.panta.rb_hibrido.addActionListener(this);
        this.panta.rb_nafta.addActionListener(this);
 
      //  this.panta.cmb_marca.addMouseListener(this);
        this.panta.cmb_modelo.addMouseListener(this);
        //Listado de modelo
           
        listarAuto();

        modeloControlador.filtrarModelos_auto();
        versionControlador.filtrarVersiones_auto();

    }


    @Override
    public void actionPerformed(ActionEvent e) { 
        
     if(e.getSource() == panta.btn_agregar_auto){selector = 1;
        System.out.println("Agregar en Pantalla Modelo"+selector);
         System.out.println ("pase por autocontroller linea 135 agregar/modificar/borrar/limpiar/volver - SELECTOR " +selector);
        }
        else if(e.getSource() == panta.btn_modificar_auto){selector = 2;
         System.out.println("Modificar en Pantalla Modelo" + selector);}
        else if(e.getSource() == panta.btn_borrar_auto){selector = 3;
        System.out.println("Borrar en Pantalla Modelo" + selector);}
        else if(e.getSource() == panta.btn_limpiar_auto){selector = 4;}
        else if(e.getSource() == panta.btn_volver){selector = 5;}
        
        
        
        System.out.println ("pase por autocontroller linea 146 agregar/modificar/borrar/limpiar/volver - SELECTOR " +selector);
        
    
        switch (selector){
            case 1:{ // AGREGAR -- seleccionamos en comboBox y verificamos seleccion
                panta.btn_agregar_auto.setEnabled(true);
                                
               {if(panta.cmb_marca.getSelectedItem().equals("")      
                    || panta.cmb_modelo.getSelectedItem().equals("")
                    || panta.cmb_version.getSelectedItem().equals("")){
                    JOptionPane.showMessageDialog(null, "Seleccione Marca, Modelo, Version");}
                }    
                // verificamos que los TXT_Field esten completos
                if(panta.txt_anio.getText().equals("") 
                    || panta.txt_precio.getText().equals("")
                    || panta.txt_kilometraje.getText().equals("")){
                    //|| panta.txt_condicion.getText().equals("")){ 
                    JOptionPane.showMessageDialog(null, "Complete Año, Precio, Kilometraje, Combustible, Puertas, Condición y a continuacion Agregar"); 
                        {break;}
                }
                  
                        else {
                                String combustibleSeleccionado = "";
                                panta.rb_diesel.setActionCommand("diesel");
                                panta.rb_gnc.setActionCommand("gnc");
                                panta.rb_hibrido.setActionCommand("hibrido");
                                panta.rb_nafta.setActionCommand("nafta");
                                panta.ckb_condicion.setText("0Km");

                                combustibleSeleccionado = panta.btnG_combustible.getSelection().getActionCommand();
                                System.out.println("combustible seleccionado en Autocontroller "+ combustibleSeleccionado);

                // Verificamos seleccion de SPINNER Puertas
                   
                int puertasSeleccionado = 0;
                    SpinnerModel model = new SpinnerNumberModel(1, 1, 10, 1);
                    do
                            if (panta.sp_puertas == null) {
                             panta.sp_puertas = new JSpinner(model);
                            JOptionPane.showMessageDialog(null, "seleccione numero de puertas");
                            }else { puertasSeleccionado = (Integer) panta.sp_puertas.getValue();
                                    System.out.println("Debe seleccionar Numero de puertas");
                                    puertasSeleccionado = (Integer) panta.sp_puertas.getValue();
                                    System.out.println ("pase por autocontroller linea 189 SPINNER Puertas - SELECTOR " + puertasSeleccionado);}
                    while (puertasSeleccionado == 0);
                    
                  Integer respuesta = JOptionPane.showConfirmDialog(null,"confirma valores seleccionados");
                   
               if (respuesta != JOptionPane.YES_OPTION) {break;}
                  
                //Realiza la modificacion
                    MarcaDao marcaDao = new MarcaDao();
                    //llamamos al metodo en DAO para buscar
                    int idmarca = marcaDao.buscarIdmarca(panta.cmb_marca.getSelectedItem().toString());
                    ModeloDao modeloDao = new ModeloDao();
                    int idmodelo = modeloDao.buscarIdmodelo(panta.cmb_modelo.getSelectedItem().toString());
                    VersionDao versionDao = new VersionDao();
                    int idversion = versionDao.buscarIdversion(panta.cmb_version.getSelectedItem().toString());
                    
                    auto.setIdmarca(idmarca);
                    auto.setIdmodelo(idmodelo);
                    auto.setIdversion(idversion);
                    auto.setAnio(Integer.parseInt(panta.txt_anio.getText()));
                    auto.setPrecio(Float.parseFloat(panta.txt_precio.getText()));
                    auto.setKilometros(Integer.parseInt(panta.txt_kilometraje.getText()));
                     if( panta.ckb_condicion.isSelected())  {
                         condicion = "0Km";
                         auto.setCondicion(condicion);}
                        else {auto.setCondicion(panta.txt_condicion.getText());}
                    auto.setCombustible(combustibleSeleccionado);
                    auto.setPuertas(puertasSeleccionado);
                                    
                        
                if(autoDao.agregarAuto(auto)){
                    limpiarTabla();
                    limpiarCampos();
                    listarAuto();
                    JOptionPane.showMessageDialog(null, "Se agrego el auto");
                } else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar el auto");
                    }
                System.out.println ("pase por autocontroller linea 227 Metodo AGREGAR");
                 panta.btn_agregar_auto.setEnabled(true);
            
                }
            }
            break;

            case 2:  // MODIFICAR -- seleccionamos en comboBox y verificamos seleccion
               {// deshabilito la opcion agregar  
                panta.btn_agregar_auto.setEnabled(false);  
               if(panta.cmb_marca.getSelectedItem().equals("")     
                    || panta.cmb_modelo.getSelectedItem().equals("")
                    || panta.cmb_version.getSelectedItem().equals("")){
                    JOptionPane.showMessageDialog(null, "Seleccione Marca, Modelo, Version");}
                   
                // verificamos que los TXT_Field esten completos
                if(panta.txt_anio.getText().equals("") 
                    || panta.txt_precio.getText().equals("")
                    || panta.txt_kilometraje.getText().equals("")){
                   // || panta.txt_condicion.getText().equals("")){ 
                    JOptionPane.showMessageDialog(null, "Complete Año, Precio, Kilometraje, Combustible, Puertas, Condición y a continuacion Agregar"); 
                        {break;}
                }
                  
                        else {
                                String combustibleSeleccionado = "";
                                panta.rb_diesel.setActionCommand("diesel");
                                panta.rb_gnc.setActionCommand("gnc");
                                panta.rb_hibrido.setActionCommand("hibrido");
                                panta.rb_nafta.setActionCommand("nafta");
                                panta.ckb_condicion.setText("0Km");

                                combustibleSeleccionado = panta.btnG_combustible.getSelection().getActionCommand();
                                System.out.println("combustible seleccionado en Autocontroller "+ combustibleSeleccionado);

                // Verificamos seleccion de SPINNER Puertas
                   
               
                    SpinnerModel model = new SpinnerNumberModel(1, 1, 10, 1);
                    do
                            if (panta.sp_puertas == null) {
                             panta.sp_puertas = new JSpinner(model);
                            JOptionPane.showMessageDialog(null, "seleccione numero de puertas");
                            }else { int puertasSeleccionado = (Integer) panta.sp_puertas.getValue();
                                    System.out.println("Debe seleccionar Numero de puertas");
                                    
                                    System.out.println ("pase por autocontroller linea 273 SPINNER Puertas - SELECTOR " + puertasSeleccionado);}
                    while (panta.sp_puertas == null);
                   
                  Integer respuesta = JOptionPane.showConfirmDialog(null,"confirma valores seleccionados");
                   
               if (respuesta != JOptionPane.YES_OPTION) {break;}
               int puertasSeleccionado = (Integer) panta.sp_puertas.getValue(); 
                //Realiza la modificacion
                   int idauto = Integer.parseInt(panta.txt_idauto.getText());
                System.out.println ("pase por autocontroller linea 282 seleccionado idauto = " + idauto);                
                    MarcaDao marcaDao = new MarcaDao();
                    //llamamos al metodo en DAO para buscar
                     int idmarca = marcaDao.buscarIdmarca(panta.cmb_marca.getSelectedItem().toString());
                    ModeloDao modeloDao = new ModeloDao();
                    int idmodelo = modeloDao.buscarIdmodelo(panta.cmb_modelo.getSelectedItem().toString());
                    VersionDao versionDao = new VersionDao();
                    int idversion = versionDao.buscarIdversion(panta.cmb_version.getSelectedItem().toString());
                    auto.setIdmarca(idmarca);
                    auto.setIdmodelo(idmodelo);
                    auto.setIdversion(idversion);
                    auto.setAnio(Integer.parseInt(panta.txt_anio.getText()));
                    auto.setPrecio(Float.parseFloat(panta.txt_precio.getText()));
                    auto.setKilometros(Integer.parseInt(panta.txt_kilometraje.getText()));
                     if( panta.ckb_condicion.isSelected())  {
                         condicion = "0Km";
                         auto.setCondicion(condicion);}
                        else {auto.setCondicion(panta.txt_condicion.getText());}
                    auto.setCombustible(combustibleSeleccionado);
                    auto.setPuertas(puertasSeleccionado);
                    auto.setIdauto(idauto);
                        
                if(autoDao.modificarAuto(auto)){
                    limpiarTabla();
                    limpiarCampos();
                    listarAuto();
                    JOptionPane.showMessageDialog(null, "Se modifico el auto");
                    break;
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el auto");
                    }
                
            }
                    System.out.println ("pase por autocontroller linea 315 Metodo MODIFICAR");
                    panta.btn_agregar_auto.setEnabled(true);
            
            }
            break;

            case 3:   //BORRAR auto
                { if(panta.txt_idauto.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
                    } else{
                          //Realiza el borrado
                       int id = Integer.parseInt(panta.txt_idauto.getText());
                         if(autoDao.borrarAuto(id)){
                          limpiarTabla();
                          limpiarCampos();
                          listarAuto();
                          JOptionPane.showMessageDialog(null, "Se eliminó el auto");
                            } else{
                            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar el auto");
                            }
            System.out.println ("pase por autocontroller linea 335 Metodo BORRAR");
                     }
                      panta.btn_agregar_auto.setEnabled(true);
                }
            break;
                
            case 4:
                        //IMPIAAR y volver a Realizas el listado
                    {   limpiarTabla();
                        limpiarCampos();
                        listarAuto();  
                        panta.btn_agregar_auto.setEnabled(true);
                    }
            break;
            default :
            { System.out.println ("pase por autocontroller linea 350 Default Switch");}
        }
        
            if(e.getSource().equals(panta.cmb_marca)) { //listarModelos();
               
                    panta.cmb_marca.getSelectedItem();
                    modeloControlador.filtrarModelos_auto();
                    versionControlador.filtrarVersiones_auto();
                  System.out.println("Autocontroller linea 326 - cambie de marca en el BOX ");}   
            if(e.getSource().equals(panta.cmb_modelo)) { //listarVersiones();
                     panta.cmb_modelo.getSelectedItem();
                     modeloControlador.filtrarModelos_auto();
                    
                     
            if(e.getSource().equals(panta.cmb_version)) { //listarVersiones();
                     panta.cmb_version.getSelectedItem();
                     versionControlador.filtrarVersiones_auto();
            }

  System.out.println("Autocontroller linea 345 - cambie de modelo en el BOX ");}
      
     }
            
    @Override
    public void mouseClicked(MouseEvent e) {
             if(e.getSource() == panta.tb_auto){
            int row = panta.tb_auto.rowAtPoint(e.getPoint()); 
            panta.txt_idauto.setText(panta.tb_auto.getValueAt(row,0).toString());
            idautoAux1 = Integer.parseInt(panta.tb_auto.getValueAt(row,0).toString());
            System.out.println("Autocontroller linea 407 - idautoAux1 = "+ idautoAux1);  
        
            panta.txt_idauto.setText(panta.tb_auto.getValueAt(row,0).toString());
            panta.cmb_marca.setSelectedItem(panta.tb_auto.getValueAt(row,1).toString());
            panta.cmb_modelo.setSelectedItem(panta.tb_auto.getValueAt(row,2).toString());
            panta.cmb_version.setSelectedItem(panta.tb_auto.getValueAt(row,3).toString());  
            panta.txt_anio.setText(panta.tb_auto.getValueAt(row,4).toString());
            panta.txt_precio.setText(panta.tb_auto.getValueAt(row,5).toString());
            panta.txt_kilometraje.setText(panta.tb_auto.getValueAt(row,6).toString());
            panta.sp_puertas.setValue(panta.tb_auto.getValueAt(row,8));
            if (panta.tb_auto.getValueAt(row,9).equals("0Km"))
                { panta.ckb_condicion.setSelected(true);}
            else {panta.ckb_condicion.setSelected(false);
                    panta.txt_condicion.setText(panta.tb_auto.getValueAt(row,9).toString());}
            String combustible = panta.tb_auto.getValueAt(row,7).toString();
             System.out.println("Autocontroller linea 374 combustible =" + combustible ); 
            switch (combustible) {
                
                case "nafta" :{
                    panta.rb_nafta.setEnabled(true);
                    panta.rb_nafta.setSelected(true);}
                break;
                
                case "diesel" :{
                    panta.rb_diesel.setEnabled(true);
                    panta.rb_diesel.setSelected(true);}
                break;
                
                case "gnc" : {
                    panta.rb_gnc.setEnabled(true);
                    panta.rb_gnc.setSelected(true);}
                break;
                
                case "hibrido" :{
                panta.rb_hibrido.setEnabled(true);
                panta.rb_hibrido.setSelected(true);}
                break;
                default : {System.out.println("Tipo de combustible no reconocido");}
                break;
                }
   
             
             modeloControlador.filtrarModelos_auto();
             versionControlador.filtrarVersiones_auto();

            //Deshabilitar
            panta.btn_agregar_auto.setEnabled(true);
                }
             
          
          
            if(e.getSource() == panta.btn_limpiar_auto) {
                
            
                 modeloControlador.filtrarModelos_auto();
                 versionControlador.filtrarVersiones_auto();
            }
            
            if(e.getSource() == panta.btnG_combustible) {
                String combustibleSeleccionado = "";
                 panta.rb_diesel.setActionCommand(combustibleSeleccionado = "diesel");
                 panta.rb_gnc.setActionCommand(combustibleSeleccionado = "gnc");
                 panta.rb_hibrido.setActionCommand(combustibleSeleccionado = "hibrido");
                 panta.rb_nafta.setActionCommand(combustibleSeleccionado = "nafta");

                 System.out.println("combustible seleccionado en Autocontroller "+ combustibleSeleccionado);
              
                 }
    }
                    
    
    @Override
    public void mousePressed(MouseEvent e) {
         
        
    }

    @Override
    public void mouseReleased(MouseEvent e){     
         if(e.getSource() == panta.tb_auto){
            int row = panta.tb_auto.rowAtPoint(e.getPoint()); 
            panta.txt_idauto.setText(panta.tb_auto.getValueAt(row,0).toString());
            idautoAux1 = Integer.parseInt(panta.tb_auto.getValueAt(row,0).toString());
            System.out.println("Autocontroller linea 407 - idautoAux1 = "+ idautoAux1);  
        
            panta.txt_idauto.setText(panta.tb_auto.getValueAt(row,0).toString());
            panta.cmb_marca.setSelectedItem(panta.tb_auto.getValueAt(row,1).toString());
            panta.cmb_modelo.setSelectedItem(panta.tb_auto.getValueAt(row,2).toString());
            panta.cmb_version.setSelectedItem(panta.tb_auto.getValueAt(row,3).toString());  
            panta.txt_anio.setText(panta.tb_auto.getValueAt(row,4).toString());
            panta.txt_precio.setText(panta.tb_auto.getValueAt(row,5).toString());
            panta.txt_kilometraje.setText(panta.tb_auto.getValueAt(row,6).toString());
            panta.txt_condicion.setText(panta.tb_auto.getValueAt(row,9).toString());
}
         
         if(e.getSource() == panta.cmb_modelo){
                           modeloControlador.filtrarModelos_auto();
                           versionControlador.filtrarVersiones_auto();}
          
          if(e.getSource() == panta.cmb_version){
                           modeloControlador.filtrarModelos_auto();
                           versionControlador.filtrarVersiones_auto();}
          
          
          if(e.getSource() == panta.btn_volver){

                    this.panta.btn_agregar_auto.removeActionListener(this);
                    this.panta.btn_modificar_auto.removeActionListener(this);
                    this.panta.btn_borrar_auto.removeActionListener(this);
                    this.panta.btn_limpiar_auto.removeActionListener(this);
                    this.panta.btn_volver.removeActionListener(this);
                    this.panta.tb_auto.removeMouseListener(this);
                    this.panta.cmb_marca.removeActionListener(this);
                    this.panta.cmb_modelo.removeActionListener(this);
                    this.panta.cmb_version.removeActionListener(this);
                    this.panta.rb_diesel.removeActionListener(this);
                    this.panta.rb_gnc.removeActionListener(this);
                    this.panta.rb_hibrido.removeActionListener(this);
                    this.panta.rb_nafta.removeActionListener(this);
                }

    }  
    

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}

    @Override
    public void keyTyped(KeyEvent e) { }

    @Override
    public void keyPressed(KeyEvent e) {}

    @Override
    public void keyReleased(KeyEvent e) {
            if(e.getSource().equals( panta.tb_auto))
            limpiarTabla();
            listarAuto();
    }

        
    public void listarAuto(){
       
    System.out.println("pase por AutoControlador - listarAuto - linea 362");
        
           
        List<Auto> list = autoDao.listarAuto();
               model = (DefaultTableModel) panta.tb_auto.getModel();
        Object[] row = new Object[10];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
          
            row[0] = list.get(i).getIdauto();
            row[1] = list.get(i).getNombre_marca();
            row[2] = list.get(i).getNombre_modelo();
            row[3] = list.get(i).getNombre_version();
            row[4] = list.get(i).getAnio();
            row[5] = list.get(i).getPrecio();
            row[6] = list.get(i).getKilometros();
            row[7] = list.get(i).getCombustible();
            row[8] = list.get(i).getPuertas();
            row[9] = list.get(i).getCondicion();
      
            model.addRow(row);
          
        }   
    }
       
    public void limpiarTabla (){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_idauto.setText("");
        panta.txt_anio.setText("");
        panta.txt_precio.setText("");
        panta.txt_kilometraje.setText("");
        panta.txt_condicion.setText("");
        panta.sp_puertas.setValue(0);
    }
    
    // parte nueva
   
 public void listarModelos(){
       
    System.out.println("pase por AutoControlador - listarModelos - linea 474");
        
   panta.cmb_modelo.removeAllItems();
       int SelectedIdmarca = marcaDao.buscarIdmarca(panta.cmb_marca.getSelectedItem().toString());
       System.out.println("pase por AutoControlador - listarmodelo idmarca = " + SelectedIdmarca);
        List<Auto> list = modeloDao.listarModeloxMarca(SelectedIdmarca);

        Object[] row = new Object[1];
        
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getNombre_modelo();
            panta.cmb_modelo.addItem(list.get(i).getNombre_modelo());
 
            }   
    
         System.out.println("pase por AutoControlador - listarmodelo valor cmb_modelo = " + panta.cmb_modelo.getSelectedItem().toString());
   }
 /* funciona pero no se utiliza porque trae todas las versiones sin filtro
 public void listarVersiones(){
       
    System.out.println("pase por AutoControlador - listarVersiones - linea 590");
       panta.cmb_version.removeAllItems();
       int SelectedIdmarca = marcaDao.buscarIdmarca(panta.cmb_marca.getSelectedItem().toString()); 
       listarModelos();
       int SelectedIdmodelo = modeloDao.buscarIdmodelo(panta.cmb_modelo.getSelectedItem().toString());
       System.out.println("pase por AutoControlador - listarmodelo idmodelo = " + SelectedIdmodelo);
      
        List<Auto> list = versionDao.listarVersionxModelo(SelectedIdmarca,SelectedIdmodelo);
         Object[] row = new Object[1];
           for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getNombre_version();
            panta.cmb_version.addItem(list.get(i).getNombre_version());
      
    
        }  
   }
 
 
 
 */

}