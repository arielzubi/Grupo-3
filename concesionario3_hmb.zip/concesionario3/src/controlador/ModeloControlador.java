package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Marca;
import model.MarcaDao;
import view.Panta_modelo;
import model.Modelo;
import model.ModeloDao;
import model.Version;
import model.VersionDao;
import view.Panta_modelo;
import view.Panta_principal;
import view.Panta_marca;
import view.Panta_version;
import view.Panta_auto;
import model.Auto;
import model.AutoDao;

/**
 *
 * hmb
 */

public class ModeloControlador implements ActionListener, MouseListener, KeyListener {
    private Modelo modelo;
    private ModeloDao modeloDao;
    private Panta_modelo panta;
    private Panta_principal pantaprincipal;
    private Panta_marca pantamarca;
    private int selector;
    private MarcaDao marcaDao;
    private VersionDao versionDao;
    private AutoDao autoDao;
    private Panta_version pantaversion;
    private Panta_auto pantaauto;
 
    DefaultTableModel model = new DefaultTableModel();

    public ModeloControlador(Modelo modelo, ModeloDao modeloDao, Panta_modelo panta,
            Panta_marca pantamarca, MarcaDao marcaDao, Panta_version pantaversion, Panta_auto pantaauto) {
        this.modelo = modelo;
        this.modeloDao = modeloDao;
        this.panta = panta;
        this.pantamarca = pantamarca;
        this.marcaDao = marcaDao;
        this.pantaversion = pantaversion;
        this.pantaauto = pantaauto;
        
         this.panta.btn_agregar_modelo.addActionListener(this);
         System.out.println("Listener registrado: btn_agregar_modelo");
        //Botón de modificar modelo
        this.panta.btn_modificar_modelo.addActionListener(this);
        System.out.println("Listener registrado: btn_modificar_modelo");
        //Botón de borrar modelo
        this.panta.btn_borrar_modelo.addActionListener(this);
        System.out.println("Listener registrado: btn_borrar_modelo");
        //Botón de limpiar
        this.panta.btn_limpiar_modelo.addActionListener(this);
        System.out.println("Listener registrado: btn_limpiar_modelo");
        
        this.pantaversion.cbm_marca_version.addActionListener(this);
        this.pantaauto.cmb_marca.addActionListener(this);
        //Listado de modelo
        this.panta.tb_modelo.addMouseListener(this);
              
        listarModelos(); 
         this.panta.txt_modelo.addKeyListener(this);
         listarModelos(); 
    }

    

    @Override
    public void actionPerformed(ActionEvent e) {
        
        
  if(e.getSource() == panta.btn_agregar_modelo){selector = 1;
        System.out.println("Agregar en Pantalla Modelo"+selector);
         System.out.println ("pase por autocontroller linea 62 agregar/modificar/borrar/limpiar/volver - SELECTOR " +selector);
        }
        else if(e.getSource() == panta.btn_modificar_modelo){selector = 2;
         System.out.println("Modificar en Pantalla Modelo" + selector);}
        else if(e.getSource() == panta.btn_borrar_modelo){selector = 3;
        System.out.println("Borrar en Pantalla Modelo" + selector);}
        else if(e.getSource() == panta.btn_limpiar_modelo){selector = 4;}
        else if(e.getSource() == panta.btn_volver_modelo){selector = 5;}
        
        
        System.out.println ("pase por autocontroller linea 87 agregar/modificar/borrar/limpiar/volver - SELECTOR " +selector);
        
    
        switch (selector){
            case 1: // AGREGAR -- seleccionamos en comboBox y verificamos seleccion
               { boolean datosValidos = true;
               
               
                    if (e.getSource() != panta.cbm_marca_modelo){
                        JOptionPane.showMessageDialog(null,"Usted selecciono la marca " + panta.cbm_marca_modelo.getSelectedItem());
                               if (JOptionPane.showConfirmDialog(null,"Continua con la carga, [yes] para continuar"
                                       + "                       [No] para terminar, vuelva a elegir del combo",
                                       "[yes]",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
                                 { datosValidos = true;}
                                else {break;}
                        
                        datosValidos = false;}
        
               do 
                   if (panta.txt_modelo.getText().trim().equals("")) {
                          String nombre_modelo = JOptionPane.showInputDialog("Ingrese el Modelo:");
                          
                          System.out.println ("pase por modelocontroller linea 109 modelo = " + nombre_modelo);
                          
                           panta.txt_modelo.setText(nombre_modelo);
                                     
                        if (panta.txt_modelo.getText().equals("")) {datosValidos = false;}
                        else {
                               if (JOptionPane.showConfirmDialog(null,"Continua con la carga",
                                       "[yes]",JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) 
                                 { datosValidos = true;}
                                else {datosValidos = false;}
                             }
               }    
                while (datosValidos != true);
                
                int idmarca = marcaDao.buscarIdmarca(String.valueOf(panta.cbm_marca_modelo.getSelectedItem()));
                
                modelo.setNombre_modelo(panta.txt_modelo.getText());
                modelo.setIdmarca(idmarca);
                System.out.println ("pase por modelocontroller linea 126 sali del loop de control txt_modelo " + modelo + "idmarca = "+idmarca);
              
                if(modeloDao.agregarNombre_modelo(modelo)){
                    limpiarTabla();
                    limpiarCampos();
                    listarModelos();
                    JOptionPane.showMessageDialog(null, "Se agrego el modelo");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar la modelo");
                    }
                System.out.println ("pase por modeloController linea 117 Metodo AGREGAR");
                 panta.btn_agregar_modelo.setEnabled(true);
            }
            break;
                
                
            case 2:  // MODIFICAR -- seleccionamos en comboBox y verificamos seleccion
               { if (panta.txt_modelo.getText().trim().equals("")) {
                          JOptionPane.showMessageDialog(null,"Seleccione un registro de la Tabla");
                          
                          System.out.println ("pase por modelocontroller linea 147" );
                            
                         break;}
                    //llamamos al metodo DAO para buscar
                    // recuperamos los idmarca y idmodelo para la modificacion
                    
                    int idmodelo = modeloDao.buscarIdmodelo(panta.txt_modelo.getText());
                    int idmarca = marcaDao.buscarIdmarca(String.valueOf(panta.cbm_marca_modelo.getSelectedItem())); 
                    
                  
                    String modeloActualizada = JOptionPane.showInputDialog("Por favor actualice el Modelo");
                    panta.txt_modelo.setText(modeloActualizada);
                    
                    System.out.println ("pase por modeloController linea 160 Metodo MODIFICAR idmodelo = " + idmodelo);
                    // guardamos atributos en modelo
                    modelo.setIdmodelo(idmodelo);
                    modelo.setNombre_modelo(panta.txt_modelo.getText());
                    modelo.setIdmarca(idmarca);
                     //Realiza la modificacion en base de datos
                if (modeloDao.modificarNombre_modelo (modelo)){
                    limpiarTabla();
                    limpiarCampos();
                    listarModelos();
                    JOptionPane.showMessageDialog(null, "Se modifico el modelo");
                } else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el modelo");
                    }
                
            System.out.println ("pase por modeloController linea 175 Metodo MODIFICAR");
                panta.btn_agregar_modelo.setEnabled(true);
            }
            break;
                

            case 3:   //BORRAR modelo
                { if(panta.txt_modelo.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
                    } else{
                          //Realiza el borrado

                         int id = modeloDao.buscarIdmodelo(panta.txt_modelo.getText());   
                      
                      if(modeloDao.borrarNombre_modelo(id)){
                          limpiarTabla();
                          limpiarCampos();
                          listarModelos();
                          JOptionPane.showMessageDialog(null, "Se eliminó la modelo");
                            } else{
                            JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar la modelo");
                            }
            System.out.println ("pase por modelocontroller linea 170 Metodo BORRAR");
                     }
                      panta.btn_agregar_modelo.setEnabled(true);
                }
            break;
                
            case 4:
                        //IMPIAAR y volver a Realizas el listado
                    {   limpiarTabla();
                        limpiarCampos();
                        listarModelos();  
                        panta.btn_agregar_modelo.setEnabled(true);
                    }
            break;
            default :
            { System.out.println ("pase por modeloController linea 164 Default Switch");}
        }
       }
     

    @Override
    public void mouseClicked(MouseEvent e) {
            if(e.getSource() == panta.cbm_marca_modelo){
            int idmodelo = modeloDao.buscarIdmodelo(panta.txt_modelo.getText());
            panta.txt_idmodelo.setText(Integer.toString(idmodelo));
            int row = panta.tb_modelo.rowAtPoint(e.getPoint());
            panta.txt_idmodelo.setText(panta.tb_modelo.getValueAt(row,0).toString());
            panta.txt_modelo.setText(panta.tb_modelo.getValueAt(row,1).toString());
            panta.cbm_marca_modelo.setSelectedItem(panta.tb_modelo.getValueAt(row,0).toString());
            //Deshabilitar
            panta.btn_agregar_modelo.setEnabled(false);
        }
    }
    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tb_modelo){
            int idmodelo = modeloDao.buscarIdmodelo(panta.txt_modelo.getText());
            panta.txt_idmodelo.setText(Integer.toString(idmodelo));
            int row = panta.tb_modelo.rowAtPoint(e.getPoint());
            
            panta.txt_modelo.setText(panta.tb_modelo.getValueAt(row,1).toString());
             panta.cbm_marca_modelo.setSelectedItem(panta.tb_modelo.getValueAt(row,0).toString());
            //Deshabilitar
            panta.btn_agregar_modelo.setEnabled(false);
        
        
            
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(e.getSource().equals( panta.txt_modelo))
            limpiarTabla();
            listarModelos();
    }
 
        public void listarModelos(){
       
        if (panta.txt_modelo.getText().equals("")){
        List<Modelo> list = modeloDao.listarNombre_modelo();
        model = (DefaultTableModel) panta.tb_modelo.getModel();
        Object[] row = new Object[2];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            //row[0] = list.get(i).getIdmodelo(); // no tenemos idmodelo para mostrar en la tabla
            row[0] = list.get(i).getNombre_marca();
            row[1] = list.get(i).getNombre_modelo();
            pantaversion.cbm_modelo_version.addItem(list.get(i).getNombre_modelo());
            pantaauto.cmb_modelo.addItem(list.get(i).getNombre_modelo());
        model.addRow(row);
        }
    }
 }

    //Limpiar la tabla
    public void limpiarTabla (){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_idmodelo.setText("");
        panta.txt_modelo.setText("");
  }

}