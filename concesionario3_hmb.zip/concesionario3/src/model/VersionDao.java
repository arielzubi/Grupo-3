package model;

/**
 *
 * @author cfp40
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import view.Panta_version;

    

public class VersionDao {
    
    Conexion cn = new Conexion();
    Connection con;
      
    PreparedStatement pst;
    ResultSet rs;
    JComboBox cmb_marca_version = new JComboBox<>();
    JComboBox cmb_modelo_version = new JComboBox<>();
    
    public boolean agregarNombre_version(Version version) {
    // a copmtinuacion en el comando a enviar a MySQL, se escriben los campos de la misma forma que se declararon en las tablas
    System.out.println("en VersionDao query AGREGAR linea 32");
    String query = "INSERT INTO version (nombre_version, idmodelo) VALUES(?,?)";
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         //a continuacion los version.getXXXXXX se escriben de la misma forma que se declararon en la clase Nombre_version
         pst.setString( 1,version.getNombre_version());
         pst.setInt( 2,version.getIdmodelo());
         pst.execute();
                return true;
         } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, "Error al registrar el version" + e);
                return false;
         }
}
public boolean modificarNombre_version(Version version) {
        System.out.println("en ModeloDao query MODIFCAR linea 46");
        String query = "UPDATE version  SET nombre_version = ?"
                        + "WHERE idversion = ? ";
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         //hacemos validaciones para asegurar que los campos no esten vacíos
              // Validar campos vacíos
        
         //a continuacion los version.getXXXXXX se escriben de la misma forma que se declararon en la clase Nombre_version
         
         pst.setString(1,version.getNombre_version());
         pst.setInt(2,version.getIdversion());
         pst.execute();
                return true;
         } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, "Error al actualizar el version" + e);
                return false;
         }  
}
public boolean borrarNombre_version(int idversion) {
        
        System.out.println("en ModeloDao query BORRAR linea 68");
         String query = "DELETE FROM version WHERE idversion = " + idversion;
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         // no necesito las definiciones de los metodos anteriores, porque solo necesito el id para borrar el registro
         pst.execute();
                return true;
         } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, "Error al borrar el version" + e);
                return false;
         }              
}

public List listarNombre_version() {
    System.out.println ("pase por versionDao linea 82 query SELECT listarNombre_version");
    List<Version> list_version = new ArrayList();
    String query = "SELECT ma.nombre_marca, model.nombre_modelo,ver.nombre_version FROM " +
" marca AS ma INNER JOIN modelo AS model ON ma.idmarca = model.idmarca INNER JOIN version as ver "
            + " ON ver.idmodelo = model.idmodelo;";
                 //" order by au.idversion asc;"
                 
    System.out.println ("pase por versionDao linea 87 despues de query SELECT listarNombre_version");
         try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         rs = pst.executeQuery();
         //a continuacion los version.getXXXXXX se escriben de la misma forma que se declararon en la clase Nombre_version
         while(rs.next()) {
              Version version = new Version();
             //version.setIdversion(rs.getInt("idversion"));  // no estamos utilizando el idversion en la tabla

             cmb_marca_version.addItem(rs.getString("nombre_marca"));
             cmb_modelo_version.addItem(rs.getString("nombre_modelo"));
             version.setNombre_marca(rs.getString("nombre_marca"));
             version.setNombre_modelo(rs.getString("nombre_modelo"));
             version.setNombre_version(rs.getString("nombre_version"));
         list_version.add(version);
              System.out.println ("pase por versionDao linea 101 query SELECT listarNombre_version DESPUES");
         }
                 } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, e.toString());
                         }
                return list_version;
         }   
    
//Buscar id de version
    public int buscarIdversion(String nombre_version){
        int id = 0;
        String query = "SELECT idversion FROM version WHERE nombre_version = '" + nombre_version + "'";
        try {
         con = cn.conectar();
         pst = con.prepareStatement(query);
         rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idversion");            
                System.out.println ("pase por versionDao linea 118 query SELECT buscarIdversion");
            }
        } catch (SQLException e) 
        { JOptionPane.showMessageDialog(null, "Error al buscar el id de version" + e);}
        return id;
        }
    }