package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import view.Panta_auto;
import view.Panta_consulta;
import view.Panta_marca;
import view.Panta_modelo;
import view.Panta_version;

public class MarcaDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public MarcaDao() {
    }
    //Agregar Version
    public boolean agregarMarca(Marca marca){
        String query = "INSERT INTO marca (nombre_marca) VALUES(?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,marca.getNombre_marca());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar la Marca" + e);
            return false;
        }
    }
    
    //Modificar auto
    public boolean modificarMarca(Marca marca){
        String query = "UPDATE marca SET nombre_marca = ? WHERE idmarca = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,marca.getNombre_marca());
            pst.setInt(2, marca.getIdmarca());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar la marca" + e);
            return false;
        }
    }

    //Borrar auto
    public boolean borrarMarca(int id){
        String query = "DELETE FROM marca WHERE idmarca = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar la Marca" + e);
            return false;
        }
    }

    //Listar auto
    public List listarMarca(){
        List<Marca> list_Marcas = new ArrayList();
        String query = "SELECT * FROM marca ORDER BY nombre_marca ASC";
        Panta_auto pantaut = new Panta_auto();
        Panta_modelo pantamo = new Panta_modelo();
        Panta_version pantaver = new Panta_version();
        Panta_consulta pantacon = new Panta_consulta();
                        
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Marca marca = new Marca();
                marca.setIdmarca(rs.getInt("idmarca"));
                marca.setNombre_marca(rs.getString("nombre_marca"));
                pantaut.cmb_marca.addItem(rs.getString("nombre_marca"));
                pantamo.cmb_marca_modelo.addItem(rs.getString("nombre_marca"));
                pantaver.cmb_marca_version.addItem(rs.getString("nombre_marca"));
                pantacon.cmb_marca_consulta.addItem(rs.getString("nombre_marca"));
                
                list_Marcas.add(marca);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_Marcas;
    }    
    
    //Buscar id de auto
    public int buscarIdmarca(String nombre){
        int id = 0;
        String query = "SELECT idmarca FROM marca WHERE nombre_marca = '" + nombre + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idmarca");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id la Marca" + e);
        }
        return id;
    }

}