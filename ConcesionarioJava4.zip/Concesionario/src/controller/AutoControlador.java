
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Version;
import model.VersionDao;
import model.Auto;
import model.AutoDao;
import model.Marca;
import model.MarcaDao;
import model.Modelo;
import model.ModeloDao;
import view.Panta_auto;

public class AutoControlador implements ActionListener, MouseListener, KeyListener {
    private Auto auto;
    private AutoDao autoDao;
    private Marca marca = new Marca();
    private MarcaDao marcaDao = new MarcaDao();
    private Version version = new Version();
    private VersionDao versionDao = new VersionDao();
    private Modelo modelo = new Modelo();
    private ModeloDao modeloDao = new ModeloDao();
    private Panta_auto panta;
   

    DefaultTableModel model = new DefaultTableModel();

    public AutoControlador(Auto auto, AutoDao autoDao, Panta_auto panta) {
        this.auto = auto;
        this.autoDao = autoDao;
        this.panta = panta;
        
        //Botón de registrar auto
        this.panta.btn_agregar_auto.addActionListener(this);
        //Botón de modificar auto
        this.panta.btn_modificar_auto.addActionListener(this);
        //Botón de borrar auto
        this.panta.btn_borrar_auto.addActionListener(this);
        //Botón de limpiar
        this.panta.btn_limpiar_auto.addActionListener(this);
        
        //Listado de auto
        this.panta.tb_auto.addMouseListener(this);
        this.panta.rb_nafta.addMouseListener(this);
        this.panta.rb_diesel.addMouseListener(this);
        this.panta.rb_gnc.addMouseListener(this);
        this.panta.rb_hibrido.addMouseListener(this);
        this.panta.sp_puertas.addMouseListener(this);
        this.panta.chbox_nuevo.addMouseListener(this);
        
              
        listarAutos(); 
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == panta.btn_agregar_auto){
            
                                        
                //Realiza el agregado
                int idMar = marcaDao.buscarIdmarca(panta.cmb_marca.getSelectedItem().toString());
                auto.setIdmarca(idMar);
                int idMod = modeloDao.buscarIdmodelo(panta.cmb_modelo.getSelectedItem().toString());
                auto.setIdmodelo(idMod);
                int idVer = versionDao.buscarIdversion(panta.cmb_version.getSelectedItem().toString());
                auto.setIdversion(idVer);
                auto.setAnio(Integer.parseInt(panta.txt_anio.getText()));
                auto.setPrecio(Float.parseFloat(panta.txt_precio.getText()));
                auto.setKilometros(Integer.parseInt(panta.txt_kilometraje.getText()));
                auto.setPuertas(Integer.parseInt(panta.sp_puertas.getValue().toString()));
                
                if(panta.chbox_nuevo.isSelected()){
                    auto.setCondicion("Nuevo");
                }else {
                    auto.setCondicion("Usado");
                }
                
                if(panta.rb_nafta.isSelected()){
                    auto.setCombustible("Nafta");
                }else if (panta.rb_diesel.isSelected()){
                    auto.setCombustible("Diesel");
                }else if (panta.rb_gnc.isSelected()){
                    auto.setCombustible("GNC");    
                }else if (panta.rb_hibrido.isSelected()){
                    auto.setCombustible("Hibrido");    
                }
                           
                               
                if(autoDao.agregarAuto(auto)){
                    limpiarTabla();
                    limpiarCampos();
                    listarAutos();
                    JOptionPane.showMessageDialog(null, "Se agregó el auto");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar el auto");
                }
            }
        else if(e.getSource() == panta.btn_modificar_auto){
            //verifica si el campo id está vacío
            if(panta.cmb_marca.getSelectedItem().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza la modificación
                int idMar = marcaDao.buscarIdmarca(panta.cmb_marca.getSelectedItem().toString());
                auto.setIdmarca(idMar);
                int idMod = modeloDao.buscarIdmodelo(panta.cmb_modelo.getSelectedItem().toString());
                auto.setIdmodelo(idMod);
                int idVer = versionDao.buscarIdversion(panta.cmb_version.getSelectedItem().toString());
                auto.setIdversion(idVer);
                auto.setAnio(Integer.parseInt(panta.txt_anio.getText()));
                auto.setPrecio(Float.parseFloat(panta.txt_precio.getText()));
                auto.setKilometros(Integer.parseInt(panta.txt_kilometraje.getText()));
                auto.setPuertas(Integer.parseInt(panta.sp_puertas.getValue().toString()));
                
                if(panta.chbox_nuevo.isSelected()){
                    auto.setCondicion("Nuevo");
                }else {
                    auto.setCondicion("Usado");
                }
                               
                if(panta.rb_nafta.isSelected()){
                    auto.setCombustible("Nafta");
                }else if (panta.rb_diesel.isSelected()){
                    auto.setCombustible("Diesel");
                }else if (panta.rb_gnc.isSelected()){
                    auto.setCombustible("GNC");    
                }else if (panta.rb_hibrido.isSelected()){
                    auto.setCombustible("Hibrido");    
                }
                
                if(autoDao.modificarAuto(auto)){
                    limpiarTabla();
                    limpiarCampos();
                    listarAutos();
                    JOptionPane.showMessageDialog(null, "Se modificó el auto");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el auto");
                }
            }
        }else if(e.getSource() == panta.btn_borrar_auto){
            //verifica si el campo id está vacío
            if(panta.txt_idauto.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza el borrado
                int id = Integer.parseInt(panta.txt_idauto.getText());
                
                if(autoDao.borrarAuto(id)){
                    limpiarTabla();
                    limpiarCampos();
                    listarAutos();
                    JOptionPane.showMessageDialog(null, "Se eliminó el auto");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar el auto");
                }
            }
        }else if(e.getSource() == panta.btn_limpiar_auto){
                limpiarTabla();
                limpiarCampos();
                listarAutos();    
                panta.btn_agregar_auto.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tb_auto){
            int row = panta.tb_auto.rowAtPoint(e.getPoint());
            panta.cmb_marca.setSelectedItem(panta.tb_auto.getValueAt(row,0).toString());
            panta.cmb_modelo.setSelectedItem(panta.tb_auto.getValueAt(row,1).toString());
            panta.cmb_version.setSelectedItem(panta.tb_auto.getValueAt(row,2).toString());
            panta.txt_anio.setText(panta.tb_auto.getValueAt(row,3).toString());
            panta.txt_precio.setText(panta.tb_auto.getValueAt(row,4).toString());
            panta.txt_kilometraje.setText(panta.tb_auto.getValueAt(row,5).toString());
           
            if(panta.tb_auto.getValueAt(row, 6).equals("nafta")){
                    panta.rb_nafta.setSelected(true);
                }else if (panta.tb_auto.getValueAt(row, 6).equals("diesel")){
                    panta.rb_diesel.setSelected(true);
                }else if (panta.tb_auto.getValueAt(row, 6).equals("gnc")){
                    panta.rb_gnc.setSelected(true);  
                }else if (panta.tb_auto.getValueAt(row, 6).equals("hibrido")){
                    panta.rb_hibrido.setSelected(true);
                }
            panta.sp_puertas.setValue(Integer.parseInt(panta.tb_auto.getValueAt(row, 7).toString()));
                                   
            if(panta.tb_auto.getValueAt(row, 8).equals("nuevo")){
                panta.chbox_nuevo.setSelected(true);              
            }else {
                panta.chbox_nuevo.setSelected(false);
                
               }
            panta.txt_idauto.setText(panta.tb_auto.getValueAt(row,9).toString());
                             
                      
            

            //Deshabilitar
            panta.btn_agregar_auto.setEnabled(false);
        }
    }
    
    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    //Listar todos los autoes
    public void listarAutos(){

        
        panta.cmb_marca.removeAllItems();
        panta.cmb_modelo.removeAllItems();
        panta.cmb_version.removeAllItems();

        List<Auto> list = autoDao.listarAuto();
        model = (DefaultTableModel) panta.tb_auto.getModel();
        Object[] row = new Object[10];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getNombre_marca();
            row[1] = list.get(i).getNombre_modelo();
            row[2] = list.get(i).getNombre_version();
            row[3] = list.get(i).getAnio();
            row[4] = list.get(i).getPrecio();
            row[5] = list.get(i).getKilometros();
            row[6] = list.get(i).getCombustible();
            row[7] = list.get(i).getPuertas();
            row[8] = list.get(i).getCondicion();
            row[9] = list.get(i).getIdauto();
                        
            model.addRow(row);
            
            panta.cmb_marca.addItem(list.get(i).getNombre_marca());
            panta.cmb_modelo.addItem(list.get(i).getNombre_modelo());
            panta.cmb_version.addItem(list.get(i).getNombre_version());

            
        }
    }


    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_anio.setText("");
        panta.txt_precio.setText("");
        panta.txt_kilometraje.setText("");
        panta.txt_idauto.setText("");
        panta.rb_nafta.setSelected(false);
        panta.rb_diesel.setSelected(false);
        panta.rb_gnc.setSelected(false);
        panta.rb_hibrido.setSelected(false);
        panta.chbox_nuevo.setSelected(false);
    }
 

}